import os
import re

DASHBOARD_PATH = '/Users/hoangminhduc/Downloads/GreenOS/htx-dashboard.html'

with open(DASHBOARD_PATH, 'r', encoding='utf-8') as f:
    text = f.read()

# ==============================================================================
# 1. FIX B2B TABLE & VIEW
# ==============================================================================
b2b_old_section = text[text.find('id="view-b2b-orders"'):text.find('id="view-ai-content"')]

b2b_new_section = '''id="view-b2b-orders">
          <div class="member-top-nav-bar">
            <button class="btn-coursue-back" onclick="showOverviewView()">
              <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
              Quay lại Dashboard
            </button>
            <div class="member-breadcrumb">
              Phân hệ: <strong>Order Hub B2B — Điều Phối Nông Sản Siêu Thị & Đại Lý</strong>
            </div>
          </div>

          <div class="member-card-container">
            <!-- 4 Mini KPI Cards for B2B -->
            <div class="kpi-mini-grid">
              <div class="kpi-mini-card">
                <span class="label">TỔNG HỢP ĐỒNG SỈ</span>
                <span class="val" id="b2b-kpi-total-val" style="color: var(--brand-700);">148.500.000 đ</span>
                <span class="hint">4 Hợp đồng bao tiêu lớn</span>
              </div>
              <div class="kpi-mini-card">
                <span class="label">SẢN LƯỢNG XUẤT SỈ</span>
                <span class="val">4.5 Tấn</span>
                <span class="hint">Chuối, Trà, Mật ong, Bưởi</span>
              </div>
              <div class="kpi-mini-card">
                <span class="label">ĐÃ NGHIỆM THU</span>
                <span class="val" style="color: var(--brand-700);">3 / 4 Đơn</span>
                <span class="hint">Đạt 75% chỉ tiêu giao tháng</span>
              </div>
              <div class="kpi-mini-card">
                <span class="label">KÊNH ĐỐI TÁC</span>
                <span class="val">WinMart · MM · GO!</span>
                <span class="hint">Chuỗi bán lẻ toàn quốc</span>
              </div>
            </div>

            <div class="table-top-toolbar-header">
              <div class="table-title-side">
                <h3>Danh Sách Hợp Đồng & Đơn Buôn Sỉ B2B</h3>
                <span class="pill-category-badge mint" id="b2b-contracts-badge">4 Hợp Đồng Đang Gom</span>
              </div>
              <div class="table-filter-side">
                <button class="hero-pill-btn-dark" onclick="openAddB2BContractModal()">
                  <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
                  Thêm Hợp Đồng Mới
                </button>
              </div>
            </div>

            <!-- Bảng B2B chuẩn có overflow-x: auto và 4 hợp đồng đầy đủ -->
            <div style="overflow-x: auto; border: 1px solid var(--slate-200); border-radius: 14px;">
              <table class="member-product-table" style="width: 100%;">
                <thead>
                  <tr>
                    <th>MÃ ĐƠN HÀNG</th>
                    <th>ĐỐI TÁC / SIÊU THỊ</th>
                    <th>NÔNG SẢN THU GOM</th>
                    <th>SỐ LƯỢNG</th>
                    <th>GIÁ BUÔN XUẤT KHO</th>
                    <th>TỔNG GIÁ TRỊ</th>
                    <th>TRẠNG THÁI</th>
                    <th style="text-align: right;">THAO TÁC</th>
                  </tr>
                </thead>
                <tbody id="b2b-orders-table-body">
                  <tr class="clickable-row" onclick="openDispatchSlipModal('WM-8821')">
                    <td><strong>#B2B-9821</strong><br><span style="font-size: 11.5px; color: var(--slate-500);">Ký: 04/10/2026</span></td>
                    <td>
                      <div style="font-weight: 800; color: var(--slate-900);">WinMart Miền Bắc</div>
                      <div style="font-size: 12px; color: var(--slate-500);">Kho Trung Tâm Mê Linh, Hà Nội</div>
                    </td>
                    <td><span class="table-tag-dept">Chuối Sấy Giòn Yên Bình</span></td>
                    <td style="font-weight: 700;">1.200 túi (250g)</td>
                    <td style="font-weight: 700; color: var(--slate-700);">14.500 đ/túi</td>
                    <td><strong style="color: var(--brand-700); font-size: 15px;">17.400.000 đ</strong></td>
                    <td><span class="status-badge-clean approved">Đang đóng gói</span></td>
                    <td style="text-align: right;">
                      <button class="btn-table-action-view" onclick="event.stopPropagation(); openDispatchSlipModal('WM-8821')">
                        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4H7v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                        In Phiếu Kho
                      </button>
                    </td>
                  </tr>

                  <tr class="clickable-row" onclick="openDispatchSlipModal('MM-9822')">
                    <td><strong>#B2B-9822</strong><br><span style="font-size: 11.5px; color: var(--slate-500);">Ký: 05/10/2026</span></td>
                    <td>
                      <div style="font-weight: 800; color: var(--slate-900);">MM Mega Market Thăng Long</div>
                      <div style="font-size: 12px; color: var(--slate-500);">Phạm Văn Đồng, Cầu Giấy, Hà Nội</div>
                    </td>
                    <td><span class="table-tag-dept">Trà Bát Tiên Sao Lửa OCOP</span></td>
                    <td style="font-weight: 700;">300 hộp (200g)</td>
                    <td style="font-weight: 700; color: var(--slate-700);">162.000 đ/hộp</td>
                    <td><strong style="color: var(--brand-700); font-size: 15px;">48.600.000 đ</strong></td>
                    <td><span class="status-badge-clean pending">Đang chờ gom</span></td>
                    <td style="text-align: right;">
                      <button class="btn-table-action-view" onclick="event.stopPropagation(); showLogisticsView()">
                        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0"/></svg>
                        Lịch Tuyến Xe
                      </button>
                    </td>
                  </tr>

                  <tr class="clickable-row" onclick="openDispatchSlipModal('GC-9823')">
                    <td><strong>#B2B-9823</strong><br><span style="font-size: 11.5px; color: var(--slate-500);">Ký: 06/10/2026</span></td>
                    <td>
                      <div style="font-weight: 800; color: var(--slate-900);">GO! / Big C Long Biên</div>
                      <div style="font-size: 12px; color: var(--slate-500);">TTTM Savico Megamall Hà Nội</div>
                    </td>
                    <td><span class="table-tag-dept">Mật Ong Hoa Rừng Tự Nhiên OCOP</span></td>
                    <td style="font-weight: 700;">150 chai (500ml)</td>
                    <td style="font-weight: 700; color: var(--slate-700);">200.000 đ/chai</td>
                    <td><strong style="color: var(--brand-700); font-size: 15px;">30.000.000 đ</strong></td>
                    <td><span class="status-badge-clean paused">Tạm dừng chờ hũ</span></td>
                    <td style="text-align: right;">
                      <button class="btn-table-action-view" onclick="event.stopPropagation(); showSuppliesView()">
                        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                        Kiểm Kho Hũ
                      </button>
                    </td>
                  </tr>

                  <tr class="clickable-row" onclick="openDispatchSlipModal('BHX-9824')">
                    <td><strong>#B2B-9824</strong><br><span style="font-size: 11.5px; color: var(--slate-500);">Ký: 07/10/2026</span></td>
                    <td>
                      <div style="font-weight: 800; color: var(--slate-900);">Bách Hóa Xanh (Hub Hà Nội)</div>
                      <div style="font-size: 12px; color: var(--slate-500);">KCN Quang Minh, Hà Nội</div>
                    </td>
                    <td><span class="table-tag-dept">Bưởi Da Xanh Yên Bình Loại 1</span></td>
                    <td style="font-weight: 700;">1.500 trái (2.2 Tấn)</td>
                    <td style="font-weight: 700; color: var(--slate-700);">35.000 đ/trái</td>
                    <td><strong style="color: var(--brand-700); font-size: 15px;">52.500.000 đ</strong></td>
                    <td><span class="status-badge-clean approved">Đang vận chuyển</span></td>
                    <td style="text-align: right;">
                      <button class="btn-table-action-view" onclick="event.stopPropagation(); openGPSFleetModal('Tuyến 3 - Xe Giao Bách Hóa Xanh')">
                        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        Định Vị GPS
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- -------------------------------------------------------------------
             VIEW 4: MÀN HÌNH KỊCH BẢN AI & MARKETING
             ------------------------------------------------------------------- -->
        <div '''

text = text.replace(b2b_old_section, b2b_new_section)

# Update submitAddB2BContract to dynamically insert row
old_submit_b2b = '''    function submitAddB2BContract() {
      const partner = document.getElementById('b2b-partner-input').value;
      const prod = document.getElementById('b2b-prod-select').value;
      const qty = document.getElementById('b2b-qty-input').value;
      closeGenericModal('modal-add-b2b-contract');
      showToast(`✅ ĐÃ LƯU THÀNH CÔNG HỢP ĐỒNG ${partner} (${qty})!`);
    }'''

new_submit_b2b = '''    function submitAddB2BContract() {
      const partner = document.getElementById('b2b-partner-input').value;
      const prod = document.getElementById('b2b-prod-select').value;
      const qty = document.getElementById('b2b-qty-input').value;
      const price = document.getElementById('b2b-price-input').value;

      const tbody = document.getElementById('b2b-orders-table-body');
      if (tbody) {
        const orderId = 'B2B-98' + (25 + Math.floor(Math.random() * 50));
        const newRow = document.createElement('tr');
        newRow.className = 'clickable-row';
        newRow.onclick = () => openDispatchSlipModal(orderId);
        newRow.innerHTML = `
          <td><strong>#${orderId}</strong><br><span style="font-size: 11.5px; color: var(--slate-500);">Ký: Hôm nay</span></td>
          <td>
            <div style="font-weight: 800; color: var(--slate-900);">${partner}</div>
            <div style="font-size: 12px; color: var(--slate-500);">Hợp đồng mới duyệt trực tuyến</div>
          </td>
          <td><span class="table-tag-dept">${prod}</span></td>
          <td style="font-weight: 700;">${qty}</td>
          <td style="font-weight: 700; color: var(--slate-700);">Theo hợp đồng</td>
          <td><strong style="color: var(--brand-700); font-size: 15px;">${price}</strong></td>
          <td><span class="status-badge-clean approved">Đã ký kết</span></td>
          <td style="text-align: right;">
            <button class="btn-table-action-view" onclick="event.stopPropagation(); openDispatchSlipModal('${orderId}')">
              <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4H7v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
              In Phiếu Kho
            </button>
          </td>
        `;
        tbody.prepend(newRow);

        const badge = document.getElementById('b2b-contracts-badge');
        if (badge) badge.innerText = `${tbody.querySelectorAll('tr').length} Hợp Đồng Đang Gom`;
      }

      closeGenericModal('modal-add-b2b-contract');
      showToast(`Đã lưu và kích hoạt hợp đồng ${partner}!`);
    }'''

text = text.replace(old_submit_b2b, new_submit_b2b)

# ==============================================================================
# 2. REPLACE ALL EMOJIS IN BUTTONS WITH CLEAN INLINE SVG ICONS
# ==============================================================================

# SVG helper templates
svg_bot = '<svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4M8 16h.01M16 16h.01"/></svg>'
svg_arrow_right = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>'
svg_chev_left = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>'
svg_chev_right = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>'
svg_heart = '<svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>'
svg_ext_arrow = '<svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>'
svg_phone = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>'
svg_sparkles = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>'
svg_copy = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/></svg>'
svg_speaker = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg>'
svg_excel = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>'
svg_zap = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>'
svg_plus = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="vertical-align: -2px; margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>'
svg_pin = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>'
svg_doc = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>'
svg_tag = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>'
svg_box = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>'
svg_refresh = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>'
svg_check = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="vertical-align: -2px; margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>'
svg_print = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4H7v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>'
svg_download = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>'
svg_rocket = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>'
svg_megaphone = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg>'
svg_close = '<svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>'
svg_mic = '<svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/></svg>'
svg_send = '<svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>'

# Specific button string replacements
button_replacements = [
    # Top bar Copilot
    ('<span style="font-size: 16px;">🤖</span>\n            <span style="font-size: 13px;">AI Copilot</span>', svg_bot + ' <span>AI Copilot</span>'),

    # Hero CTA banner arrow
    ('<div class="banner-cta-arrow">➔</div>', f'<div class="banner-cta-arrow">{svg_arrow_right}</div>'),

    # Carousel arrows
    ('<button class="nav-arrow-btn" onclick="scrollCoursueGrid(-1)">‹</button>', f'<button class="nav-arrow-btn" onclick="scrollCoursueGrid(-1)" title="Trước">{svg_chev_left}</button>'),
    ('<button class="nav-arrow-btn active-primary" onclick="scrollCoursueGrid(1)">›</button>', f'<button class="nav-arrow-btn active-primary" onclick="scrollCoursueGrid(1)" title="Sau">{svg_chev_right}</button>'),

    # Floating heart button
    ('<button class="floating-heart-btn" title="Lưu trữ" onclick="toggleFavorite(this, event)">♡</button>', f'<button class="floating-heart-btn" title="Lưu trữ" onclick="toggleFavorite(this, event)">{svg_heart}</button>'),

    # Circle arrow action
    ('<button class="circle-arrow-action" title="In phiếu đóng gói" onclick="openDispatchSlipModal(\'WM-8821\')">↗</button>', f'<button class="circle-arrow-action" title="In phiếu đóng gói" onclick="openDispatchSlipModal(\'WM-8821\')">{svg_ext_arrow}</button>'),
    ('<button class="circle-arrow-action" title="Xem vận đơn" onclick="openDispatchSlipModal(\'SHP-8821\')">↗</button>', f'<button class="circle-arrow-action" title="Xem vận đơn" onclick="openDispatchSlipModal(\'SHP-8821\')">{svg_ext_arrow}</button>'),

    # Right rail Zalo call
    ('<button class="rail-zalo-call-btn" onclick="openZaloCallModal(\'Bác Ba (Hộ 04 - 0912.345.889)\')">\n                📞 Gọi Zalo\n              </button>', f'<button class="rail-zalo-call-btn" onclick="openZaloCallModal(\'Bác Ba (Hộ 04 - 0912.345.889)\')">\n                {svg_phone} Gọi Zalo\n              </button>'),

    # Pagination buttons
    ('<button class="btn-page-nav" id="btn-prev-page" onclick="goToPage(currentPage - 1)">‹ Trước</button>', f'<button class="btn-page-nav" id="btn-prev-page" onclick="goToPage(currentPage - 1)">{svg_chev_left} Trước</button>'),
    ('<button class="btn-page-nav" id="btn-next-page" onclick="goToPage(currentPage + 1)">Sau ›</button>', f'<button class="btn-page-nav" id="btn-next-page" onclick="goToPage(currentPage + 1)">Sau {svg_chev_right}</button>'),

    # AI Studio buttons
    ('<button class="hero-pill-btn-dark" onclick="openAIGeneratorModal()">✨ Sinh Kịch Bản Mới</button>', f'<button class="hero-pill-btn-dark" onclick="openAIGeneratorModal()">{svg_sparkles} Sinh Kịch Bản Mới</button>'),
    ('<button class="hero-pill-btn-white" onclick="showToast(\'Đã sao chép kịch bản vào clipboard!\')">📋 Sao Chép Kịch Bản</button>', f'<button class="hero-pill-btn-white" onclick="showToast(\'Đã sao chép kịch bản vào clipboard!\')">{svg_copy} Sao Chép Kịch Bản</button>'),
    ('<button class="btn-table-action-view" onclick="openVoicePreviewModal(\'Kịch Bản TikTok Bác Ba\', \'Bà con ơi, chuối vườn nhà Ba quả đẫy đà thế này mà không làm chuối sấy giòn thì tiếc lắm! Hôm nay HTX trợ giá combo 3 gói miễn phí ship tận nhà, bấm ngay giỏ hàng góc trái nghen!\')">🔊 Nghe Đọc Thử Giọng AI</button>', f'<button class="btn-table-action-view" onclick="openVoicePreviewModal(\'Kịch Bản TikTok Bác Ba\', \'Bà con ơi, chuối vườn nhà Ba quả đẫy đà thế này mà không làm chuối sấy giòn thì tiếc lắm! Hôm nay HTX trợ giá combo 3 gói miễn phí ship tận nhà, bấm ngay giỏ hàng góc trái nghen!\')">{svg_speaker} Nghe Đọc Thử Giọng AI</button>'),

    # Settlement buttons
    ('<button class="hero-pill-btn-white" onclick="exportSettlementExcel()">📊 Xuất File Excel</button>', f'<button class="hero-pill-btn-white" onclick="exportSettlementExcel()">{svg_excel} Xuất File Excel</button>'),
    ('<button class="hero-pill-btn-dark" onclick="openBatchPayoutModal()">⚡ Chuyển Khoản Hàng Loạt</button>', f'<button class="hero-pill-btn-dark" onclick="openBatchPayoutModal()">{svg_zap} Chuyển Khoản Hàng Loạt</button>'),

    # Logistics buttons
    ('<button class="hero-pill-btn-white" onclick="broadcastLogisticsZalo()">📢 Gửi Zalo Nhắc Bà Con</button>', f'<button class="hero-pill-btn-white" onclick="broadcastLogisticsZalo()">{svg_megaphone} Gửi Zalo Nhắc Bà Con</button>'),
    ('<button class="hero-pill-btn-dark" onclick="openAddRouteModal()">➕ Thêm Tuyến Xe</button>', f'<button class="hero-pill-btn-dark" onclick="openAddRouteModal()">{svg_plus} Thêm Tuyến Xe</button>'),
    ('<button class="hero-pill-btn-green" style="width: 100%; justify-content: center;" onclick="openGPSFleetModal(\'Tuyến 1 - Thôn Đồng Cát\')">📍 Xem Vị Trí Xe Trên Bản Đồ</button>', f'<button class="hero-pill-btn-green" style="width: 100%; justify-content: center;" onclick="openGPSFleetModal(\'Tuyến 1 - Thôn Đồng Cát\')">{svg_pin} Xem Vị Trí Xe Trên Bản Đồ</button>'),
    ('<button class="hero-pill-btn-white" style="width: 100%; justify-content: center;" onclick="openNghiemThuModal(\'Tuyến 2 - Thôn Suối Hai\')">📄 Xem Phiếu Nghiệm Thu</button>', f'<button class="hero-pill-btn-white" style="width: 100%; justify-content: center;" onclick="openNghiemThuModal(\'Tuyến 2 - Thôn Suối Hai\')">{svg_doc} Xem Phiếu Nghiệm Thu</button>'),
    ('<button class="hero-pill-btn-white" style="width: 100%; justify-content: center;" onclick="openDispatchSlipModal(\'WM-8821\')">🏷️ In Vận Đơn Kèm QR</button>', f'<button class="hero-pill-btn-white" style="width: 100%; justify-content: center;" onclick="openDispatchSlipModal(\'WM-8821\')">{svg_tag} In Vận Đơn Kèm QR</button>'),

    # Supplies buttons
    ('<button class="hero-pill-btn-dark" onclick="openPackagingOrderModal()">📦 Đặt In 3.000 Túi Mới</button>', f'<button class="hero-pill-btn-dark" onclick="openPackagingOrderModal()">{svg_box} Đặt In 3.000 Túi Mới</button>'),

    # Radar button
    ('<button class="hero-pill-btn-dark" onclick="refreshAIRadar()">⚡ Quét Lại Giá AI</button>', f'<button class="hero-pill-btn-dark" onclick="refreshAIRadar()">{svg_refresh} Quét Lại Giá AI</button>'),

    # Modal buttons
    ('<button class="hero-pill-btn-green" onclick="submitZaloBroadcast()">🚀 Phát Tin Nhắn Tới 142 Hộ</button>', f'<button class="hero-pill-btn-green" onclick="submitZaloBroadcast()">{svg_rocket} Phát Tin Nhắn Tới 142 Hộ</button>'),
    ('<button class="hero-pill-btn-green" onclick="submitAddB2BContract()">✓ Ký Duyệt & Lưu Hợp Đồng</button>', f'<button class="hero-pill-btn-green" onclick="submitAddB2BContract()">{svg_check} Ký Duyệt & Lưu Hợp Đồng</button>'),
    ('<button class="hero-pill-btn-dark" onclick="window.print()">🖨️ In Phiếu Xuất Kho</button>', f'<button class="hero-pill-btn-dark" onclick="window.print()">{svg_print} In Phiếu Xuất Kho</button>'),
    ('<button class="hero-pill-btn-dark" onclick="window.print()">🖨️ In Phiếu Chi Tiền Mặt</button>', f'<button class="hero-pill-btn-dark" onclick="window.print()">{svg_print} In Phiếu Chi Tiền Mặt</button>'),
    ('<button class="hero-pill-btn-dark" id="btn-trigger-ai-gen" onclick="executeAIGeneration()">✨ Tạo Kịch Bản Bằng AI</button>', f'<button class="hero-pill-btn-dark" id="btn-trigger-ai-gen" onclick="executeAIGeneration()">{svg_sparkles} Tạo Kịch Bản Bằng AI</button>'),
    ('<button class="hero-pill-btn-green" onclick="executeBatchPayout()">⚡ Xác Nhận Giải Ngân Bằng Mã OTP</button>', f'<button class="hero-pill-btn-green" onclick="executeBatchPayout()">{svg_zap} Xác Nhận Giải Ngân Bằng Mã OTP</button>'),
    ('<button class="hero-pill-btn-green" onclick="showToast(\'✅ ĐÃ KÝ DUYỆT ĐƠN ĐẶT IN 3.000 TÚI TỚI XƯỞNG TÂN Á!\'); closeGenericModal(\'modal-packaging-order\');">✓ Xác Nhận Ký Đơn Đặt In</button>', f'<button class="hero-pill-btn-green" onclick="showToast(\'✅ ĐÃ KÝ DUYỆT ĐƠN ĐẶT IN 3.000 TÚI TỚI XƯỞNG TÂN Á!\'); closeGenericModal(\'modal-packaging-order\');">{svg_check} Xác Nhận Ký Đơn Đặt In</button>'),
    ('<button class="hero-pill-btn-green" onclick="showToast(\'✅ ĐÃ DUYỆT LỆNH CẤN TRỪ 2.500.000Đ CỦA CHÚ TƯ!\'); closeGenericModal(\'modal-supply-deduction\');">✓ Duyệt Cấn Trừ & Quyết Toán</button>', f'<button class="hero-pill-btn-green" onclick="showToast(\'✅ ĐÃ DUYỆT LỆNH CẤN TRỪ 2.500.000Đ CỦA CHÚ TƯ!\'); closeGenericModal(\'modal-supply-deduction\');">{svg_check} Duyệt Cấn Trừ & Quyết Toán</button>'),
    ('<button class="hero-pill-btn-dark" onclick="showToast(\'Đang tải trọn bộ hồ sơ OCOP (PDF - 14 trang)...\');">📥 Tải Trọn Bộ Hồ Sơ (PDF)</button>', f'<button class="hero-pill-btn-dark" onclick="showToast(\'Đang tải trọn bộ hồ sơ OCOP (PDF - 14 trang)...\');">{svg_download} Tải Trọn Bộ Hồ Sơ (PDF)</button>'),
    ('<button class="hero-pill-btn-green" style="flex: 1.5; justify-content: center;" onclick="confirmVietQRPayment()">✓ Đã Chuyển Tiền</button>', f'<button class="hero-pill-btn-green" style="flex: 1.5; justify-content: center;" onclick="confirmVietQRPayment()">{svg_check} Đã Chuyển Tiền</button>'),

    # Copilot FAB and inputs
    ('<span>🤖 Trợ Lý AI HTX</span>', f'{svg_bot} <span>Trợ Lý AI HTX</span>'),
    ('<button class="copilot-btn-icon copilot-btn-mic" id="copilot-mic-btn" onclick="toggleCopilotVoiceRecording()" title="Bấm để nói bằng giọng nói">\n        🎙️\n      </button>', f'<button class="copilot-btn-icon copilot-btn-mic" id="copilot-mic-btn" onclick="toggleCopilotVoiceRecording()" title="Bấm để nói bằng giọng nói">{svg_mic}</button>'),
    ('<button class="copilot-btn-icon copilot-btn-send" onclick="submitCopilotMessage()" title="Gửi tin nhắn">\n        ➤\n      </button>', f'<button class="copilot-btn-icon copilot-btn-send" onclick="submitCopilotMessage()" title="Gửi tin nhắn">{svg_send}</button>'),

    # Copilot Quick Chips
    ('onclick="sendQuickCopilotPrompt(\'📊 Tổng hợp doanh thu & tồn kho hôm nay\')">📊 Doanh thu hôm nay</button>', f'onclick="sendQuickCopilotPrompt(\'📊 Tổng hợp doanh thu & tồn kho hôm nay\')">{svg_excel} Doanh thu hôm nay</button>'),
    ('onclick="sendQuickCopilotPrompt(\'👨‍🌾 Kiểm tra sản lượng & công nợ Bác Ba\')">👨‍🌾 Công nợ Bác Ba</button>', f'onclick="sendQuickCopilotPrompt(\'👨‍🌾 Kiểm tra sản lượng & công nợ Bác Ba\')">{svg_pin} Công nợ Bác Ba</button>'),
    ('onclick="sendQuickCopilotPrompt(\'📢 Soạn thông báo gửi nhóm Zalo 142 xã viên gom chuối\')">📢 Viết tin Zalo gom chuối</button>', f'onclick="sendQuickCopilotPrompt(\'📢 Soạn thông báo gửi nhóm Zalo 142 xã viên gom chuối\')">{svg_megaphone} Viết tin Zalo</button>'),
    ('onclick="sendQuickCopilotPrompt(\'🚚 Kiểm tra đơn sỉ B2B WinMart cần giao\')">🚚 Đơn buôn WinMart</button>', f'onclick="sendQuickCopilotPrompt(\'🚚 Kiểm tra đơn sỉ B2B WinMart cần giao\')">{svg_box} Đơn buôn WinMart</button>'),
    ('onclick="sendQuickCopilotPrompt(\'🏷️ Quy trình nâng hạng OCOP 4 sao\')">🏷️ Tiêu chuẩn OCOP 4★</button>', f'onclick="sendQuickCopilotPrompt(\'🏷️ Quy trình nâng hạng OCOP 4 sao\')">{svg_tag} Tiêu chuẩn OCOP 4★</button>'),
    ('onclick="sendQuickCopilotPrompt(\'💰 Tình hình chi trả tiền tươi đợt này\')">💰 Chi trả tiền tươi</button>', f'onclick="sendQuickCopilotPrompt(\'💰 Tình hình chi trả tiền tươi đợt này\')">{svg_zap} Chi trả tiền tươi</button>'),

    # Close modal buttons (✕)
    ('<button class="btn-close-modal" onclick="closeProductModal()" title="Đóng cửa sổ">✕</button>', f'<button class="btn-close-modal" onclick="closeProductModal()" title="Đóng cửa sổ">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-zalo-community\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-zalo-community\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-notifications-center\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-notifications-center\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-admin-profile\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-admin-profile\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-all-members-directory\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-all-members-directory\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-add-b2b-contract\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-add-b2b-contract\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-dispatch-slip\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-dispatch-slip\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-ai-generator\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-ai-generator\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-batch-payout\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-batch-payout\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-cash-voucher\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-cash-voucher\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-gps-fleet\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-gps-fleet\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-packaging-order\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-packaging-order\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-supply-handover\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-supply-handover\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-supply-deduction\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-supply-deduction\')">{svg_close}</button>'),
    ('<button class="btn-close-modal" onclick="closeGenericModal(\'modal-ocop-dossier\')">✕</button>', f'<button class="btn-close-modal" onclick="closeGenericModal(\'modal-ocop-dossier\')">{svg_close}</button>'),
    ('<button onclick="closeVietQRModal()" style="background: none; border: none; font-size: 20px; cursor: pointer; color: var(--slate-400);">✕</button>', f'<button onclick="closeVietQRModal()" style="background: none; border: none; cursor: pointer; color: var(--slate-400); display: flex; align-items: center;">{svg_close}</button>'),
    ('<button onclick="toggleAICopilot()" title="Thu nhỏ">✕</button>', f'<button onclick="toggleAICopilot()" title="Thu nhỏ">{svg_close}</button>')
]

for old, new in button_replacements:
    if old in text:
        text = text.replace(old, new)
    else:
        print('Warning: could not find exact match for:', old[:40])

with open(DASHBOARD_PATH, 'w', encoding='utf-8') as f:
    f.write(text)

print('Updated B2B table and replaced button emojis with SVGs successfully!')
