import re
import json

filepath = '/Users/hoangminhduc/Downloads/GreenOS/htx-dashboard.html'
with open(filepath, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update CSS
css_target = '#view-member-admin, #view-b2b-orders, #view-ai-content {'
css_replace = '#view-members-directory, #view-member-admin, #view-b2b-orders, #view-ai-content {'
if css_target in html:
    html = html.replace(css_target, css_replace, 1)

# 2. Update Sidebar nav-btn-members
sidebar_target = '''            <button class="sidebar-menu-btn" id="nav-btn-members" onclick="switchToMemberAdmin('bacba')">
              <svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
              Quản Trị Xã Viên
            </button>'''

sidebar_replace = '''            <button class="sidebar-menu-btn" id="nav-btn-members" onclick="showMembersDirectoryView()">
              <svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
              Quản Trị Xã Viên
            </button>'''
if sidebar_target in html:
    html = html.replace(sidebar_target, sidebar_replace, 1)

# 3. Update overview "Xem Toàn Bộ 142 Xã Viên"
overview_target = '''            <button class="btn-see-all-coursue" onclick="openAllMembersDirectoryModal()">
              Xem Toàn Bộ 142 Xã Viên
            </button>'''

overview_replace = '''            <button class="btn-see-all-coursue" onclick="showMembersDirectoryView()">
              Xem Toàn Bộ 142 Xã Viên
              <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-left: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
            </button>'''
if overview_target in html:
    html = html.replace(overview_target, overview_replace, 1)

# 4. Update view-member-admin top navigation bar
admin_nav_target = '''          <div class="member-top-nav-bar">
            <button class="btn-coursue-back" onclick="showOverviewView()">
              <span>←</span> Quay lại Tổng quan HTX
            </button>
            <div class="member-breadcrumb">
              Đang quản trị: <strong id="admin-view-breadcrumb">Bác Ba (Hộ 04)</strong>
            </div>
          </div>'''

admin_nav_replace = '''          <div class="member-top-nav-bar">
            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
              <button class="btn-coursue-back" onclick="showMembersDirectoryView()">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                Quay lại Danh Sách 50 Xã Viên
              </button>
              <button class="btn-coursue-back" onclick="showOverviewView()">
                Dashboard
              </button>
            </div>
            <div class="member-breadcrumb">
              Quản trị xã viên &gt; <strong id="admin-view-breadcrumb">Bác Ba (Hộ 04)</strong>
            </div>
          </div>'''
if admin_nav_target in html:
    html = html.replace(admin_nav_target, admin_nav_replace, 1)

# 5. Insert VIEW 1.5: TRANG QUẢN TRỊ DANH SÁCH 50 XÃ VIÊN
view_directory_html = '''        <!-- -------------------------------------------------------------------
             VIEW 1.5: TRANG QUẢN TRỊ DANH SÁCH 50 XÃ VIÊN HTX YÊN BÌNH
             ------------------------------------------------------------------- -->
        <div id="view-members-directory">
          <!-- Navigation Bar Quay Lại -->
          <div class="member-top-nav-bar">
            <button class="btn-coursue-back" onclick="showOverviewView()">
              <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
              Quay lại Dashboard
            </button>
            <div class="member-breadcrumb">
              Quản trị HTX &gt; <strong>Danh Sách 50 Hộ Xã Viên Nòng Cốt</strong>
            </div>
          </div>

          <!-- Hero Profile Quản Trị Xã Viên -->
          <div class="member-coursue-hero" style="background: linear-gradient(135deg, #064E3B 0%, #065F46 100%); color: white; padding: 26px 30px; border-radius: 20px; margin-bottom: 24px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
              <div>
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                  <span class="hero-mini-pill" style="background: rgba(255,255,255,0.2); color: white; font-weight: 700; border: none;">HỆ THỐNG QUẢN TRỊ NÔNG HỘ</span>
                  <span class="hero-mini-pill" style="background: #10B981; color: white; font-weight: 700; border: none;">142 XÃ VIÊN (DEMO 50 HỘ)</span>
                </div>
                <h2 style="font-size: 24px; font-weight: 800; margin: 0 0 6px 0; color: white;">Danh Sách Quản Trị Xã Viên HTX Nông Nghiệp Yên Bình</h2>
                <p style="margin: 0; font-size: 14px; opacity: 0.9; max-width: 650px;">Theo dõi tiến độ sản xuất, mã vùng trồng PUC, tiêu chuẩn OCOP/VietGAP và lịch giải ngân tiền tươi cho 50 hộ xã viên nòng cốt.</p>
              </div>
              <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="hero-pill-btn-white" onclick="openAddMemberModal()">
                  <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
                  Thêm Xã Viên Mới
                </button>
                <button class="hero-pill-btn-white" onclick="exportMembersListExcel()">
                  <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                  Xuất File Excel
                </button>
                <button class="hero-pill-btn-dark" style="background: rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.25);" onclick="broadcastLogisticsZalo()">
                  <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
                  Nhắn Zalo Toàn Xã
                </button>
              </div>
            </div>
          </div>

          <!-- 4 Thẻ Mini Stat Toàn Xã Viên -->
          <section class="mini-stat-trio" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px;">
            <div class="mini-stat-card">
              <div class="mini-left-content">
                <div class="mini-pastel-icon mint">
                  <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                </div>
                <div>
                  <div class="mini-stat-ratio">TỔNG XÃ VIÊN HTX</div>
                  <div class="mini-stat-title" style="color: var(--brand-700);">142 Hộ (50 Nòng Cốt)</div>
                </div>
              </div>
            </div>

            <div class="mini-stat-card">
              <div class="mini-left-content">
                <div class="mini-pastel-icon amber">
                  <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <div>
                  <div class="mini-stat-ratio">DIỆN TÍCH CANH TÁC</div>
                  <div class="mini-stat-title" style="color: var(--slate-900);">128.5 Hecta</div>
                </div>
              </div>
            </div>

            <div class="mini-stat-card">
              <div class="mini-left-content">
                <div class="mini-pastel-icon blue">
                  <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                </div>
                <div>
                  <div class="mini-stat-ratio">SẢN LƯỢNG GOM 2026</div>
                  <div class="mini-stat-title" style="color: #2563EB;">485 Tấn Nông Sản</div>
                </div>
              </div>
            </div>

            <div class="mini-stat-card">
              <div class="mini-left-content">
                <div class="mini-pastel-icon mint">
                  <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <div>
                  <div class="mini-stat-ratio">ĐÃ CHI TRẢ NÔNG DÂN</div>
                  <div class="mini-stat-title" style="color: var(--brand-700);">3.42 Tỷ Đồng</div>
                </div>
              </div>
            </div>
          </section>

          <!-- BẢNG DANH SÁCH 50 XÃ VIÊN & BỘ LỌC ĐA TẦNG -->
          <div class="member-card-container">
            <div class="table-top-toolbar-header" style="flex-direction: column; align-items: stretch; gap: 14px;">
              <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                <div class="table-title-side">
                  <h3>Danh Sách Xã Viên HTX Yên Bình</h3>
                  <span class="pill-category-badge mint" id="dir-total-count-badge">50 Hộ Dân</span>
                </div>

                <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                  <!-- Ô tìm kiếm realtime -->
                  <div style="position: relative; width: 280px;">
                    <input type="text" id="dir-search-input" class="form-input-stylish" style="padding-left: 36px; padding-top: 8px; padding-bottom: 8px; font-size: 13.5px;" placeholder="Tìm tên, SĐT, mã hộ, cây trồng..." oninput="filterDirectoryMembers()">
                    <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--slate-400);"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                  </div>

                  <!-- Dropdown filter trạng thái -->
                  <select id="dir-status-filter" class="form-input-stylish" style="width: auto; padding-top: 8px; padding-bottom: 8px; font-size: 13.5px;" onchange="filterDirectoryMembers()">
                    <option value="all">Tất cả trạng thái</option>
                    <option value="active">Đang hoạt động</option>
                    <option value="verifying">Chờ nghiệm thu</option>
                    <option value="paused">Tạm nghỉ vụ đông</option>
                  </select>

                  <!-- Dropdown filter tiêu chuẩn -->
                  <select id="dir-standard-filter" class="form-input-stylish" style="width: auto; padding-top: 8px; padding-bottom: 8px; font-size: 13.5px;" onchange="filterDirectoryMembers()">
                    <option value="all">Tất cả tiêu chuẩn</option>
                    <option value="OCOP 4★">OCOP 4 Sao Tỉnh</option>
                    <option value="OCOP 3★">OCOP 3 Sao</option>
                    <option value="VIETGAP">Chuẩn VietGAP</option>
                    <option value="HỮU CƠ">Hữu Cơ PGS</option>
                  </select>
                </div>
              </div>

              <!-- Thanh tab thôn xóm -->
              <div style="display: flex; gap: 8px; flex-wrap: wrap; padding-top: 10px; border-top: 1px solid var(--slate-100);">
                <button class="status-tab-btn active" id="dir-tab-village-all" onclick="filterDirectoryByVillage('all')">Toàn Xã (50)</button>
                <button class="status-tab-btn" id="dir-tab-village-dongcat" onclick="filterDirectoryByVillage('Thôn Đồng Cát')">Thôn Đồng Cát (14)</button>
                <button class="status-tab-btn" id="dir-tab-village-doimo" onclick="filterDirectoryByVillage('Thôn Đồi Mơ')">Thôn Đồi Mơ (10)</button>
                <button class="status-tab-btn" id="dir-tab-village-suoihai" onclick="filterDirectoryByVillage('Thôn Suối Hai')">Thôn Suối Hai (10)</button>
                <button class="status-tab-btn" id="dir-tab-village-baigiua" onclick="filterDirectoryByVillage('Thôn Bãi Giữa')">Thôn Bãi Giữa (8)</button>
                <button class="status-tab-btn" id="dir-tab-village-damsen" onclick="filterDirectoryByVillage('Thôn Đầm Sen')">Thôn Đầm Sen (8)</button>
              </div>
            </div>

            <!-- Bảng hiển thị 10 xã viên / trang -->
            <div style="overflow-x: auto; margin-top: 12px; border: 1px solid var(--slate-200); border-radius: 14px;">
              <table class="member-product-table" style="width: 100%;">
                <thead>
                  <tr>
                    <th style="width: 45px; text-align: center;">#STT</th>
                    <th>HỘ XÃ VIÊN & MÃ SỐ</th>
                    <th>ĐỊA BÀN</th>
                    <th>CÂY TRỒNG CHỦ LỰC</th>
                    <th>QUY MÔ</th>
                    <th>TIÊU CHUẨN</th>
                    <th>SẢN LƯỢNG / DOANH THU</th>
                    <th>TIẾN ĐỘ THU HOẠCH</th>
                    <th>TRẠNG THÁI</th>
                    <th style="text-align: right;">QUẢN TRỊ</th>
                  </tr>
                </thead>
                <tbody id="directory-members-table-body">
                  <!-- Được nạp tự động qua JavaScript -->
                </tbody>
              </table>
            </div>

            <!-- Phân trang 5 trang (10 xã viên / trang) -->
            <div class="table-pagination-footer" style="margin-top: 16px;">
              <div class="pagination-info-text">
                Hiển thị <strong id="dir-page-start">1</strong> - <strong id="dir-page-end">10</strong> trong số <strong id="dir-page-total">50</strong> hộ xã viên (Trang <strong id="dir-current-page">1</strong>/<span id="dir-total-pages">5</span>)
              </div>
              <div class="pagination-controls-wrap">
                <button class="btn-page-nav" id="btn-dir-prev" onclick="goToDirPage(currentDirPage - 1)">
                  <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg> Trước
                </button>
                <div class="page-number-buttons" id="dir-page-numbers"></div>
                <button class="btn-page-nav" id="btn-dir-next" onclick="goToDirPage(currentDirPage + 1)">
                  Sau <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                </button>
                <div class="page-jump-select-wrap">
                  <span>Trang:</span>
                  <select id="select-jump-dir-page" class="select-jump-control" onchange="goToDirPage(parseInt(this.value))">
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>

'''

view_2_marker = '''        <!-- -------------------------------------------------------------------
             VIEW 2: TRANG QUẢN TRỊ XÃ VIÊN & BẢNG SẢN PHẨM CÓ POPUP PHÊ DUYỆT
             ------------------------------------------------------------------- -->'''

if view_2_marker in html and 'id="view-members-directory"' not in html:
    html = html.replace(view_2_marker, view_directory_html + view_2_marker, 1)

# 6. Add Modal "Thêm Xã Viên Mới" (modal-add-farmer-member)
modal_add_member_html = '''  <!-- Modal: Thêm Xã Viên Mới Vào HTX -->
  <div id="modal-add-farmer-member" class="modal-backdrop-overlay" onclick="closeGenericModalOnBackdrop(event, 'modal-add-farmer-member')">
    <div class="modal-content-container" style="max-width: 600px;" onclick="event.stopPropagation()">
      <div class="modal-header-toolbar">
        <div>
          <h3>Thêm Hộ Xã Viên Mới Vào HTX Yên Bình</h3>
          <p>Đăng ký hộ nông dân vào hệ thống chuỗi giá trị và cấp mã số vùng trồng</p>
        </div>
        <button class="btn-close-modal" onclick="closeGenericModal('modal-add-farmer-member')"><svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>
      </div>

      <div style="display: flex; flex-direction: column; gap: 14px; margin-top: 14px;">
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 14px;">
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Họ Và Tên Chủ Hộ:</label>
            <input type="text" id="new-member-name" class="form-input-stylish" placeholder="Ví dụ: Bác Tám (Đỗ Văn Tám)">
          </div>
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Tuổi:</label>
            <input type="number" id="new-member-age" class="form-input-stylish" placeholder="Ví dụ: 58" value="55">
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Thôn / Xóm Canh Tác:</label>
            <select id="new-member-village" class="form-input-stylish">
              <option value="Thôn Đồng Cát">Thôn Đồng Cát</option>
              <option value="Thôn Đồi Mơ">Thôn Đồi Mơ</option>
              <option value="Thôn Suối Hai">Thôn Suối Hai</option>
              <option value="Thôn Bãi Giữa">Thôn Bãi Giữa</option>
              <option value="Thôn Đầm Sen">Thôn Đầm Sen</option>
            </select>
          </div>
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Số Điện Thoại (Zalo):</label>
            <input type="text" id="new-member-phone" class="form-input-stylish" placeholder="Ví dụ: 0912.888.999">
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 14px;">
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Cây Trồng / Nông Sản Chủ Lực:</label>
            <input type="text" id="new-member-crop" class="form-input-stylish" placeholder="Ví dụ: Chuối Tiêu Hồng / Trà Bát Tiên">
          </div>
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Quy Mô (Diện Tích):</label>
            <input type="text" id="new-member-area" class="form-input-stylish" placeholder="Ví dụ: 1.5 ha" value="1.5 ha">
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Tiêu Chuẩn Đăng Ký:</label>
            <select id="new-member-standard" class="form-input-stylish">
              <option value="OCOP 4★ Tỉnh">OCOP 4 Sao Tỉnh</option>
              <option value="OCOP 3★">OCOP 3 Sao</option>
              <option value="VIETGAP">Chuẩn VietGAP</option>
              <option value="HỮU CƠ">Hữu Cơ PGS</option>
            </select>
          </div>
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Sản Lượng Dự Kiến / Năm:</label>
            <input type="text" id="new-member-yield" class="form-input-stylish" placeholder="Ví dụ: 12 Tấn/năm" value="12 Tấn/năm">
          </div>
        </div>

        <div>
          <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Tài Khoản Ngân Hàng Chi Trả Tiền Tươi:</label>
          <input type="text" id="new-member-bank" class="form-input-stylish" placeholder="Ví dụ: Agribank Yên Bình - 8802.205.xxx">
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 14px;">
          <button class="btn-coursue-back" onclick="closeGenericModal('modal-add-farmer-member')">Hủy Bỏ</button>
          <button class="hero-pill-btn-green" onclick="saveNewMember()">
            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
            Lưu Hồ Sơ Xã Viên
          </button>
        </div>
      </div>
    </div>
  </div>

'''

modal_marker = '  <!-- Modal 1: Duyệt Nông Sản Đăng Lên Sàn -->'
if modal_marker in html and 'id="modal-add-farmer-member"' not in html:
    html = html.replace(modal_marker, modal_add_member_html + modal_marker, 1)

# 7. Update hideAllMainViews()
hide_views_target = '''    function hideAllMainViews() {
      document.getElementById('view-overview').style.display = 'none';'''

hide_views_replace = '''    function hideAllMainViews() {
      if (document.getElementById('view-members-directory')) document.getElementById('view-members-directory').style.display = 'none';
      document.getElementById('view-overview').style.display = 'none';'''

if hide_views_target in html:
    html = html.replace(hide_views_target, hide_views_replace, 1)

# 8. Add JavaScript dataset and management functions
js_code_to_insert = '''
    // =========================================================================
    // DỮ LIỆU VÀ QUẢN TRỊ 50 XÃ VIÊN HTX YÊN BÌNH (DEMO DIRECTORY)
    // =========================================================================
    const farmersDirectory50Data = [
      { key: "bacba", code: "HTX-YB-04", name: "Bác Ba (Nguyễn Văn Ba)", age: 62, phone: "0912.456.789", village: "Thôn Đồng Cát", crop: "Chuối Tiêu Hồng OCOP", cropClass: "mint", area: "1.8 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "14 Tấn/năm", revenue: "18.450.000 đ", orders: "48 Đơn sỉ", progress: 94, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình - 8800.205.123456", address: "Cụm 2, Thôn Đồng Cát, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đã hoàn thành 94% chỉ tiêu gom chuối sấy OCOP!" },
      { key: "lan", code: "HTX-YB-09", name: "Cô Lan (Trần Thị Lan)", age: 54, phone: "0982.112.334", village: "Thôn Đồi Mơ", crop: "Trà Bát Tiên Sao Lửa", cropClass: "mint", area: "2.4 ha", standard: "VIETGAP", stdClass: "approved", yield: "18 Tấn/năm", revenue: "32.600.000 đ", orders: "65 Đơn sỉ", progress: 88, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "Agribank Yên Bình - 8800.334.888999", address: "Xóm Đồi Chè 1, Xã Yên Bình", badge: "VIETGAP CHUẨN TỈNH", subtext: "Đạt 88% sản lượng chè búp sao lửa xuất khẩu!" },
      { key: "tuan", code: "HTX-YB-12", name: "Anh Tuấn (Hoàng Văn Tuấn)", age: 39, phone: "0973.998.776", village: "Thôn Suối Hai", crop: "Mật Ong Hoa Rừng Tự Nhiên", cropClass: "amber", area: "75 Đàn ong", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "1.200 Lít/năm", revenue: "24.200.000 đ", orders: "38 Đơn sỉ", progress: 76, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "honey_front.jpg", bank: "BIDV Yên Bình - 4501.998.776", address: "Bìa rừng tự nhiên Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 76% kế hoạch quay mật ong hoa rừng vụ hè!" },
      { key: "tu", code: "HTX-YB-31", name: "Chú Tư (Hoàng Văn Tư)", age: 58, phone: "0912.345.655", village: "Thôn Đồi Mơ", crop: "Trà Bát Tiên Sao Suốt", cropClass: "mint", area: "1.5 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "6 Tấn/năm", revenue: "21.500.000 đ", orders: "52 Đơn sỉ", progress: 78, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "ZaloPay / Agribank - 8802.345.655", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 78% kế hoạch hái chè búp sao suốt!" },
      { key: "sau", code: "HTX-YB-18", name: "Cô Sáu (Trần Thị Sáu)", age: 51, phone: "0934.567.890", village: "Thôn Suối Hai", crop: "Mật Ong Hoa Rừng Suối Hai", cropClass: "amber", area: "65 Đàn ong", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "850 Lít/năm", revenue: "14.800.000 đ", orders: "34 Đơn sỉ", progress: 92, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "honey_front.jpg", bank: "Vietcombank - 1012.345.678", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 92% kế hoạch quay mật ong hoa rừng vụ thu!" },
      { key: "thang", code: "HTX-YB-52", name: "Anh Thắng (Nguyễn Văn Thắng)", age: 42, phone: "0976.223.344", village: "Thôn Bãi Giữa", crop: "Bưởi Da Xanh Ruột Hồng", cropClass: "mint", area: "3.0 ha", standard: "VIETGAP", stdClass: "approved", yield: "25 Tấn/năm", revenue: "28.900.000 đ", orders: "41 Đơn sỉ", progress: 82, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Tiền mặt tại trạm cân", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "VIETGAP CHUẨN TỈNH", subtext: "Đạt 82% vụ bưởi da xanh ruột hồng!" },
      { key: "f_07", code: "HTX-YB-07", name: "Bác Tám (Đỗ Văn Tám)", age: 65, phone: "0915.223.881", village: "Thôn Đồng Cát", crop: "Chuối Tiêu Hồng Cấy Mô", cropClass: "mint", area: "2.0 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "16 Tấn/năm", revenue: "22.100.000 đ", orders: "50 Đơn sỉ", progress: 90, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 90% chỉ tiêu kế hoạch gom chuối cấy mô năm 2026!" },
      { key: "f_08", code: "HTX-YB-08", name: "Chú Năm (Lê Văn Năm)", age: 57, phone: "0984.332.119", village: "Thôn Đồng Cát", crop: "Gạo ST25 Lúa Rươi Hữu Cơ", cropClass: "amber", area: "3.5 ha", standard: "HỮU CƠ", stdClass: "approved", yield: "28 Tấn/năm", revenue: "38.500.000 đ", orders: "72 Đơn sỉ", progress: 85, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "HỮU CƠ PGS", subtext: "Đạt 85% chỉ tiêu kế hoạch gom gạo ST25 năm 2026!" },
      { key: "f_09", code: "HTX-YB-15", name: "Cô Bảy (Ngô Thị Bảy)", age: 53, phone: "0932.441.552", village: "Thôn Đồi Mơ", crop: "Trà Móc Câu Đồi Chè", cropClass: "mint", area: "1.6 ha", standard: "VIETGAP", stdClass: "approved", yield: "7.5 Tấn/năm", revenue: "19.800.000 đ", orders: "42 Đơn sỉ", progress: 80, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "VietinBank Yên Bình", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "VIETGAP CHUẨN TỈNH", subtext: "Đạt 80% chỉ tiêu gom trà móc câu năm 2026!" },
      { key: "f_10", code: "HTX-YB-22", name: "Bác Chín (Phạm Hữu Chín)", age: 66, phone: "0903.556.771", village: "Thôn Đầm Sen", crop: "Măng Nứa Rừng Phơi Khô", cropClass: "amber", area: "2.2 ha", standard: "OCOP 3★", stdClass: "approved", yield: "4.2 Tấn/năm", revenue: "16.400.000 đ", orders: "35 Đơn sỉ", progress: 75, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_back.jpg", bank: "Agribank Yên Bình", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Đạt 75% chỉ tiêu thu mua măng khô tự nhiên!" },
      { key: "f_11", code: "HTX-YB-25", name: "Anh Long (Trần Hải Long)", age: 36, phone: "0978.112.993", village: "Thôn Bãi Giữa", crop: "Cam Sành Lục Yên Mọng Nước", cropClass: "amber", area: "2.8 ha", standard: "VIETGAP", stdClass: "approved", yield: "22 Tấn/năm", revenue: "31.200.000 đ", orders: "55 Đơn sỉ", progress: 89, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "BIDV Yên Bình", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 89% kế hoạch gom cam sành chuỗi siêu thị!" },
      { key: "f_12", code: "HTX-YB-29", name: "Chị Mai (Vũ Thị Tuyết Mai)", age: 41, phone: "0965.882.331", village: "Thôn Suối Hai", crop: "Nấm Hương Tươi Rừng Tự Nhiên", cropClass: "mint", area: "1.2 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "3.8 Tấn/năm", revenue: "26.500.000 đ", orders: "49 Đơn sỉ", progress: 93, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_back.jpg", bank: "Agribank Yên Bình", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 93% kế hoạch nấm hương nhà màng!" },
      { key: "f_13", code: "HTX-YB-33", name: "Bác Mười (Đặng Văn Mười)", age: 63, phone: "0913.447.882", village: "Thôn Đồng Cát", crop: "Chuối Ngự Tiến Vua", cropClass: "mint", area: "1.5 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "11 Tấn/năm", revenue: "17.900.000 đ", orders: "39 Đơn sỉ", progress: 87, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 87% chỉ tiêu chuối tiến vua đóng hộp quà tết!" },
      { key: "f_14", code: "HTX-YB-35", name: "Chú Hùng (Nguyễn Quốc Hùng)", age: 59, phone: "0989.123.456", village: "Thôn Đồi Mơ", crop: "Trà San Tuyết Cổ Thụ", cropClass: "mint", area: "1.8 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "5.5 Tấn/năm", revenue: "25.800.000 đ", orders: "58 Đơn sỉ", progress: 82, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 82% vụ chè cổ thụ búp đinh cao cấp!" },
      { key: "f_15", code: "HTX-YB-38", name: "Cô Hạnh (Trương Thị Hạnh)", age: 48, phone: "0942.339.881", village: "Thôn Đầm Sen", crop: "Hạt Sen Tươi Đầm Sen OCOP", cropClass: "amber", area: "2.5 ha", standard: "OCOP 3★", stdClass: "approved", yield: "8.0 Tấn/năm", revenue: "20.400.000 đ", orders: "44 Đơn sỉ", progress: 91, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "Vietcombank", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Đạt 91% vụ sen tươi bóc vỏ rút tâm!" },
      { key: "f_16", code: "HTX-YB-41", name: "Anh Đức (Phạm Minh Đức)", age: 35, phone: "0971.228.449", village: "Thôn Bãi Giữa", crop: "Ổi Bo Nữ Hoàng Giòn Ngọt", cropClass: "mint", area: "2.0 ha", standard: "VIETGAP", stdClass: "approved", yield: "18 Tấn/năm", revenue: "21.000.000 đ", orders: "47 Đơn sỉ", progress: 79, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Techcombank", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 79% chỉ tiêu thu hoạch ổi bo sạch!" },
      { key: "f_17", code: "HTX-YB-44", name: "Chú Cường (Bùi Văn Cường)", age: 55, phone: "0918.776.552", village: "Thôn Suối Hai", crop: "Mật Ong Hoa Bạc Hà", cropClass: "amber", area: "80 Đàn ong", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "950 Lít/năm", revenue: "19.500.000 đ", orders: "36 Đơn sỉ", progress: 84, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "honey_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 84% chỉ tiêu quay mật bạc hà nguyên chất!" },
      { key: "f_18", code: "HTX-YB-47", name: "Bác Lộc (Nguyễn Phúc Lộc)", age: 67, phone: "0908.665.441", village: "Thôn Đồng Cát", crop: "Tinh Bột Nghệ Đỏ Nếp", cropClass: "amber", area: "1.4 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "2.8 Tấn/năm", revenue: "29.400.000 đ", orders: "61 Đơn sỉ", progress: 96, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_back.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 96% sản lượng nghệ đỏ sấy lọc tinh dầu!" },
      { key: "f_19", code: "HTX-YB-50", name: "Chị Thảo (Đỗ Phương Thảo)", age: 38, phone: "0969.554.112", village: "Thôn Đồi Mơ", crop: "Trà Hoa Cúc Vàng Sấy Lạnh", cropClass: "amber", area: "1.0 ha", standard: "OCOP 3★", stdClass: "approved", yield: "1.5 Tấn/năm", revenue: "18.200.000 đ", orders: "40 Đơn sỉ", progress: 77, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "MB Bank", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Đạt 77% kế hoạch trà hoa cúc dưỡng nhan!" },
      { key: "f_20", code: "HTX-YB-53", name: "Chú Nghĩa (Võ Trọng Nghĩa)", age: 56, phone: "0935.228.773", village: "Thôn Đầm Sen", crop: "Cá Rô Đồng Đầm Sen Tự Nhiên", cropClass: "blue", area: "3.0 ha", standard: "VIETGAP", stdClass: "approved", yield: "15 Tấn/năm", revenue: "33.600.000 đ", orders: "53 Đơn sỉ", progress: 88, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "Agribank Yên Bình", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 88% chỉ tiêu cá rô đầm sen cung ứng nhà hàng!" },
      { key: "f_21", code: "HTX-YB-55", name: "Bác Quý (Hoàng Đình Quý)", age: 64, phone: "0914.332.115", village: "Thôn Đồng Cát", crop: "Chuối Tiêu Hồng Xuất Khẩu", cropClass: "mint", area: "1.7 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "13 Tấn/năm", revenue: "17.200.000 đ", orders: "37 Đơn sỉ", progress: 86, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 86% chỉ tiêu chuối tiêu hồng sạch!" },
      { key: "f_22", code: "HTX-YB-58", name: "Cô Dung (Nguyễn Thị Dung)", age: 52, phone: "0987.441.229", village: "Thôn Bãi Giữa", crop: "Bưởi Diễn Cây Cổ Thụ", cropClass: "amber", area: "2.2 ha", standard: "VIETGAP", stdClass: "approved", yield: "16 Tấn/năm", revenue: "24.500.000 đ", orders: "46 Đơn sỉ", progress: 90, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 90% chỉ tiêu bưởi diễn đón tết 2026!" },
      { key: "f_23", code: "HTX-YB-61", name: "Anh Khoa (Trần Đăng Khoa)", age: 34, phone: "0962.119.884", village: "Thôn Suối Hai", crop: "Mật Ong Rừng Khoái Tự Nhiên", cropClass: "amber", area: "50 Đàn ong", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "700 Lít/năm", revenue: "16.800.000 đ", orders: "31 Đơn sỉ", progress: 71, status: "verifying", statusLabel: "Chờ nghiệm thu", statusClass: "pending", avatar: "honey_front.jpg", bank: "ZaloPay", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đang chờ kiểm định thủy phần đợt mật mới!" },
      { key: "f_24", code: "HTX-YB-64", name: "Chú Tài (Đinh Văn Tài)", age: 58, phone: "0916.883.221", village: "Thôn Đồi Mơ", crop: "Trà Shan Tuyết Đọt Vàng", cropClass: "mint", area: "1.9 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "6.2 Tấn/năm", revenue: "27.400.000 đ", orders: "59 Đơn sỉ", progress: 95, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 95% vụ trà đọt vàng OCOP 4 sao!" },
      { key: "f_25", code: "HTX-YB-67", name: "Cô Yến (Lê Hải Yến)", age: 46, phone: "0938.552.113", village: "Thôn Đầm Sen", crop: "Củ Sen Sấy Giòn Vị Muối Ớt", cropClass: "amber", area: "1.8 ha", standard: "OCOP 3★", stdClass: "approved", yield: "5.0 Tấn/năm", revenue: "15.300.000 đ", orders: "38 Đơn sỉ", progress: 83, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_back.jpg", bank: "VietinBank", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Đạt 83% sản phẩm củ sen sấy giòn ăn vặt!" },
      { key: "f_26", code: "HTX-YB-70", name: "Bác Thọ (Vũ Xuân Thọ)", age: 68, phone: "0904.771.882", village: "Thôn Đồng Cát", crop: "Gạo Nếp Nương Khẩu Hang", cropClass: "mint", area: "2.6 ha", standard: "HỮU CƠ", stdClass: "approved", yield: "19 Tấn/năm", revenue: "28.000.000 đ", orders: "49 Đơn sỉ", progress: 89, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "HỮU CƠ PGS", subtext: "Đạt 89% chỉ tiêu nếp nương đặc sản!" },
      { key: "f_27", code: "HTX-YB-72", name: "Anh Bình (Ngô Thái Bình)", age: 37, phone: "0975.334.661", village: "Thôn Bãi Giữa", crop: "Cam Canh Ngọt Mọng Nước", cropClass: "amber", area: "2.4 ha", standard: "VIETGAP", stdClass: "approved", yield: "20 Tấn/năm", revenue: "29.800.000 đ", orders: "52 Đơn sỉ", progress: 87, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "BIDV Yên Bình", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 87% chỉ tiêu cam canh sạch!" },
      { key: "f_28", code: "HTX-YB-75", name: "Chị Nga (Trần Thiên Nga)", age: 43, phone: "0981.662.339", village: "Thôn Suối Hai", crop: "Mộc Nhĩ Đen Rừng Tự Nhiên", cropClass: "mint", area: "1.0 ha", standard: "OCOP 3★", stdClass: "approved", yield: "2.5 Tấn/năm", revenue: "14.200.000 đ", orders: "33 Đơn sỉ", progress: 80, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_back.jpg", bank: "Agribank Yên Bình", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Đạt 80% chỉ tiêu mộc nhĩ rừng phơi khô!" },
      { key: "f_29", code: "HTX-YB-78", name: "Chú Tân (Phan Nhật Tân)", age: 56, phone: "0919.224.557", village: "Thôn Đồi Mơ", crop: "Trà Bát Tiên Tẩm Hoa Nhài", cropClass: "mint", area: "1.4 ha", standard: "VIETGAP", stdClass: "approved", yield: "4.8 Tấn/năm", revenue: "21.600.000 đ", orders: "43 Đơn sỉ", progress: 84, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 84% sản lượng trà ướp hoa nhài tươi!" },
      { key: "f_30", code: "HTX-YB-81", name: "Cô Thu (Phạm Lệ Thu)", age: 50, phone: "0946.883.112", village: "Thôn Đầm Sen", crop: "Ngó Sen Ngâm Dấm Chua Ngọt", cropClass: "amber", area: "1.5 ha", standard: "OCOP 3★", stdClass: "approved", yield: "6.5 Tấn/năm", revenue: "13.900.000 đ", orders: "30 Đơn sỉ", progress: 74, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "Vietcombank", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Đạt 74% kế hoạch ngó sen ngâm hũ thủy tinh!" },
      { key: "f_31", code: "HTX-YB-83", name: "Bác Vượng (Lâm Văn Vượng)", age: 61, phone: "0912.994.221", village: "Thôn Đồng Cát", crop: "Chuối Sấy Dẻo Nguyên Trái", cropClass: "mint", area: "1.9 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "15 Tấn/năm", revenue: "20.500.000 đ", orders: "45 Đơn sỉ", progress: 91, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 91% chỉ tiêu chuối sấy dẻo không đường!" },
      { key: "f_32", code: "HTX-YB-86", name: "Anh Phong (Đặng Vũ Phong)", age: 40, phone: "0977.114.553", village: "Thôn Bãi Giữa", crop: "Thanh Long Ruột Đỏ VietGAP", cropClass: "amber", area: "2.1 ha", standard: "VIETGAP", stdClass: "approved", yield: "24 Tấn/năm", revenue: "26.700.000 đ", orders: "48 Đơn sỉ", progress: 81, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "Techcombank", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 81% chỉ tiêu thanh long thắp đèn nghịch vụ!" },
      { key: "f_33", code: "HTX-YB-88", name: "Chú Lâm (Bùi Tùng Lâm)", age: 54, phone: "0983.551.776", village: "Thôn Suối Hai", crop: "Mật Ong Rừng Hoa Nhãn", cropClass: "amber", area: "70 Đàn ong", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "900 Lít/năm", revenue: "18.000.000 đ", orders: "39 Đơn sỉ", progress: 85, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "honey_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 85% chỉ tiêu mật hoa nhãn thơm lừng!" },
      { key: "f_34", code: "HTX-YB-91", name: "Cô Oanh (Lê Kiều Oanh)", age: 49, phone: "0936.442.889", village: "Thôn Đồi Mơ", crop: "Trà Búp Ô Long Yên Bình", cropClass: "mint", area: "1.7 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "5.8 Tấn/năm", revenue: "24.900.000 đ", orders: "54 Đơn sỉ", progress: 93, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "MB Bank", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 93% vụ chè ô long lên men chuẩn công nghệ Đài Loan!" },
      { key: "f_35", code: "HTX-YB-93", name: "Bác Kiên (Nguyễn Trung Kiên)", age: 65, phone: "0905.112.338", village: "Thôn Đầm Sen", crop: "Rượu Nếp Đầm Sen Ngâm Sen", cropClass: "blue", area: "2.0 ha", standard: "OCOP 3★", stdClass: "approved", yield: "4.000 Lít/năm", revenue: "23.400.000 đ", orders: "41 Đơn sỉ", progress: 88, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Đạt 88% chỉ tiêu rượu nếp chum sành ngâm củ sen!" },
      { key: "f_36", code: "HTX-YB-95", name: "Chú Sơn (Vũ Thái Sơn)", age: 57, phone: "0917.663.442", village: "Thôn Đồng Cát", crop: "Gạo Bao Thai Lùn OCOP", cropClass: "mint", area: "3.2 ha", standard: "HỮU CƠ", stdClass: "approved", yield: "25 Tấn/năm", revenue: "34.000.000 đ", orders: "68 Đơn sỉ", progress: 89, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "HỮU CƠ PGS", subtext: "Đạt 89% chỉ tiêu gạo đặc sản bao thai lùn dẻo thơm!" },
      { key: "f_37", code: "HTX-YB-98", name: "Chị Trang (Đinh Quỳnh Trang)", age: 36, phone: "0968.331.774", village: "Thôn Bãi Giữa", crop: "Dưa Lưới Hoàng Kim Nhà Màng", cropClass: "amber", area: "1.5 ha", standard: "GLOBALGAP", stdClass: "approved", yield: "17 Tấn/năm", revenue: "36.500.000 đ", orders: "62 Đơn sỉ", progress: 97, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "BIDV Yên Bình", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "GLOBALGAP", subtext: "Đạt 97% chỉ tiêu dưa lưới ngọt 14 độ brix!" },
      { key: "f_38", code: "HTX-YB-101", name: "Anh Hải (Trần Quang Hải)", age: 44, phone: "0974.882.115", village: "Thôn Suối Hai", crop: "Phấn Hoa Tươi Rừng Tự Nhiên", cropClass: "amber", area: "60 Đàn ong", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "350 kg/năm", revenue: "15.800.000 đ", orders: "34 Đơn sỉ", progress: 78, status: "verifying", statusLabel: "Chờ nghiệm thu", statusClass: "pending", avatar: "honey_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đang sấy mẫu phấn hoa kiểm định vi sinh!" },
      { key: "f_39", code: "HTX-YB-104", name: "Cô Phượng (Hoàng Kim Phượng)", age: 53, phone: "0986.229.447", village: "Thôn Đồi Mơ", crop: "Trà Xanh Tươi Đóng Gói", cropClass: "mint", area: "1.3 ha", standard: "VIETGAP", stdClass: "approved", yield: "9.0 Tấn/năm", revenue: "16.200.000 đ", orders: "37 Đơn sỉ", progress: 86, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 86% chỉ tiêu lá chè xanh tươi xuất kho hằng ngày!" },
      { key: "f_40", code: "HTX-YB-107", name: "Chú Trí (Lê Minh Trí)", age: 58, phone: "0911.554.883", village: "Thôn Đầm Sen", crop: "Trà Tim Sen Khô An Thần", cropClass: "amber", area: "1.6 ha", standard: "OCOP 3★", stdClass: "approved", yield: "850 kg/năm", revenue: "17.100.000 đ", orders: "36 Đơn sỉ", progress: 82, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_back.jpg", bank: "VietinBank", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Đạt 82% vụ tim sen khô sấy lạnh đóng lọ thủy tinh!" },
      { key: "f_41", code: "HTX-YB-110", name: "Bác Thắng (Đặng Văn Thắng)", age: 66, phone: "0909.338.221", village: "Thôn Đồng Cát", crop: "Chuối Hột Rừng Sấy Khô", cropClass: "mint", area: "1.6 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "8.5 Tấn/năm", revenue: "18.700.000 đ", orders: "42 Đơn sỉ", progress: 92, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 92% chỉ tiêu chuối hột rừng ngâm rượu bổ!" },
      { key: "f_42", code: "HTX-YB-112", name: "Anh Vũ (Nguyễn Tuấn Vũ)", age: 39, phone: "0972.441.993", village: "Thôn Bãi Giữa", crop: "Đu Đủ Ruột Đỏ VietGAP", cropClass: "amber", area: "1.8 ha", standard: "VIETGAP", stdClass: "approved", yield: "21 Tấn/năm", revenue: "19.300.000 đ", orders: "45 Đơn sỉ", progress: 84, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "VPBank", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 84% sản lượng đu đủ ngọt phục vụ siêu thị!" },
      { key: "f_43", code: "HTX-YB-115", name: "Chú Dũng (Trần Hữu Dũng)", age: 55, phone: "0985.663.118", village: "Thôn Suối Hai", crop: "Keo Ong Xịt Họng Kháng Khuẩn", cropClass: "amber", area: "85 Đàn ong", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "1.500 Lọ/năm", revenue: "25.000.000 đ", orders: "56 Đơn sỉ", progress: 94, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "honey_front.jpg", bank: "BIDV Yên Bình", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 94% sản phẩm keo ong tinh khiết OCOP!" },
      { key: "f_44", code: "HTX-YB-118", name: "Cô Thủy (Võ Bích Thủy)", age: 51, phone: "0933.772.446", village: "Thôn Đồi Mơ", crop: "Trà Bát Tiên Hút Chân Không", cropClass: "mint", area: "1.5 ha", standard: "VIETGAP", stdClass: "approved", yield: "5.2 Tấn/năm", revenue: "22.800.000 đ", orders: "51 Đơn sỉ", progress: 89, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 89% chỉ tiêu đóng túi hút chân không 200g!" },
      { key: "f_45", code: "HTX-YB-121", name: "Bác Viễn (Phan Thanh Viễn)", age: 63, phone: "0918.441.559", village: "Thôn Đầm Sen", crop: "Rau Rút Thủy Canh Đầm Sen", cropClass: "mint", area: "1.2 ha", standard: "VIETGAP", stdClass: "approved", yield: "7.2 Tấn/năm", revenue: "12.500.000 đ", orders: "29 Đơn sỉ", progress: 65, status: "paused", statusLabel: "Tạm nghỉ vụ đông", statusClass: "paused", avatar: "banana_plate.jpg", bank: "Agribank Yên Bình", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "VIETGAP", subtext: "Tạm nghỉ luân canh cải tạo nguồn nước đầm sen!" },
      { key: "f_46", code: "HTX-YB-124", name: "Chú Lợi (Hoàng Văn Lợi)", age: 57, phone: "0982.883.662", village: "Thôn Đồng Cát", crop: "Gạo Nếp Cái Hoa Vàng Đồi Cát", cropClass: "amber", area: "2.8 ha", standard: "HỮU CƠ", stdClass: "approved", yield: "22 Tấn/năm", revenue: "31.500.000 đ", orders: "60 Đơn sỉ", progress: 90, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "bac_ba_avatar.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồng Cát, Xã Yên Bình", badge: "HỮU CƠ PGS", subtext: "Đạt 90% chỉ tiêu nếp cái hoa vàng chuẩn xôi tết!" },
      { key: "f_47", code: "HTX-YB-127", name: "Anh Quang (Nguyễn Nhật Quang)", age: 38, phone: "0976.552.881", village: "Thôn Bãi Giữa", crop: "Chanh Không Hạt Vụ Thu Đông", cropClass: "mint", area: "2.3 ha", standard: "VIETGAP", stdClass: "approved", yield: "26 Tấn/năm", revenue: "27.200.000 đ", orders: "50 Đơn sỉ", progress: 83, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "banana_plate.jpg", bank: "Techcombank", address: "Thôn Bãi Giữa, Xã Yên Bình", badge: "VIETGAP", subtext: "Đạt 83% sản lượng chanh mọng nước gửi MM Mega Market!" },
      { key: "f_48", code: "HTX-YB-130", name: "Chị Vân (Bùi Cẩm Vân)", age: 42, phone: "0967.119.335", village: "Thôn Suối Hai", crop: "Mật Ong Rừng Lên Men (Mead OCOP)", cropClass: "blue", area: "55 Đàn ong", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "800 Chai/năm", revenue: "28.500.000 đ", orders: "52 Đơn sỉ", progress: 92, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "honey_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Suối Hai, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 92% sản phẩm rượu mật ong hoa rừng lên men tự nhiên!" },
      { key: "f_49", code: "HTX-YB-133", name: "Chú Chiến (Trịnh Văn Chiến)", age: 60, phone: "0915.774.228", village: "Thôn Đồi Mơ", crop: "Trà Búp Sao Tay Nghệ Nhân", cropClass: "mint", area: "2.0 ha", standard: "OCOP 4★ Tỉnh", stdClass: "approved", yield: "7.0 Tấn/năm", revenue: "30.400.000 đ", orders: "64 Đơn sỉ", progress: 96, status: "active", statusLabel: "Đang hoạt động", statusClass: "approved", avatar: "tea_front.jpg", bank: "Agribank Yên Bình", address: "Thôn Đồi Mơ, Xã Yên Bình", badge: "OCOP 4 SAO TỈNH", subtext: "Đạt 96% sản phẩm chè sao chảo gang thủ công nghệ nhân!" },
      { key: "f_50", code: "HTX-YB-142", name: "Bác Hòa (Lê Thái Hòa)", age: 69, phone: "0902.665.114", village: "Thôn Đầm Sen", crop: "Rễ Sen Sấy Khô Pha Trà", cropClass: "amber", area: "1.4 ha", standard: "OCOP 3★", stdClass: "approved", yield: "3.5 Tấn/năm", revenue: "14.600.000 đ", orders: "32 Đơn sỉ", progress: 68, status: "paused", statusLabel: "Tạm nghỉ vụ đông", statusClass: "paused", avatar: "banana_back.jpg", bank: "Agribank Yên Bình", address: "Thôn Đầm Sen, Xã Yên Bình", badge: "OCOP 3 SAO", subtext: "Tạm nghỉ vụ đông dưỡng đất đầm sen chuẩn bị xuân 2027!" }
    ];

    let currentDirPage = 1;
    const dirPageSize = 10;
    let currentDirVillage = 'all';
    let currentDirStatus = 'all';
    let currentDirStandard = 'all';
    let currentDirSearchQuery = '';

    // Tự động đồng bộ các hộ nông dân mới vào database quản trị chi tiết
    farmersDirectory50Data.forEach(f => {
      if (!farmersDatabase[f.key]) {
        farmersDatabase[f.key] = {
          name: f.name,
          meta: `Mã: ${f.code} · ${f.age} tuổi · ${f.village}, Xã Yên Bình`,
          badge: f.badge,
          avatar: f.avatar,
          revenue: f.revenue,
          yield: f.yield,
          orders: f.orders,
          phone: f.phone,
          bank: f.bank,
          address: f.address,
          progress: f.progress + '%',
          subtext: f.subtext,
          products: [
            { id: f.key + '_01', name: f.crop + ' (Chuẩn Tuyển Chọn Loại 1)', sku: 'SP-' + f.code.replace('HTX-YB-', '') + '-01', standard: f.standard, stdClass: 'mint', price: '65.000', stock: '350 đơn vị', status: 'approved', img: f.avatar, notes: 'Thu hoạch đạt chuẩn ' + f.standard + ' ghi nhận tại vườn ngày 06/10.', voiceQuote: f.crop + ' đợt này thu hoạch tươi rói đẹp lắm bà con...', voicePrice: '65.000' },
            { id: f.key + '_02', name: f.crop + ' Chế Biến Sấy Khô OCOP', sku: 'SP-' + f.code.replace('HTX-YB-', '') + '-02', standard: f.standard, stdClass: 'amber', price: '145.000', stock: '120 gói', status: 'pending', img: 'banana_back.jpg', notes: 'Mẫu chế biến gửi phòng thẩm định OCOP tỉnh nghiệm thu.', voiceQuote: 'Lô chế biến gửi thẩm định giá một trăm bốn lăm ngàn...', voicePrice: '145.000' },
            { id: f.key + '_03', name: f.crop + ' Hộp Quà Tết Đặc Sản VIP', sku: 'SP-' + f.code.replace('HTX-YB-', '') + '-03', standard: 'OCOP 4★ VIP', stdClass: 'amber', price: '280.000', stock: '45 hộp', status: 'approved', img: 'tea_front.jpg', notes: 'Đóng gói bao bì quà tặng liên kết chuỗi WinMart.', voiceQuote: 'Hộp quà biếu đặc sản hai trăm tám mươi ngàn...', voicePrice: '280.000' }
          ]
        };
      }
    });

    // HIỂN THỊ MÀN HÌNH DANH SÁCH 50 XÃ VIÊN
    function showMembersDirectoryView() {
      hideAllMainViews();
      document.getElementById('view-members-directory').style.display = 'block';
      setActiveNav('nav-btn-members');
      renderDirectoryTable();
      showToast('👥 Mở Danh Sách Quản Trị 50 Hộ Xã Viên HTX Yên Bình');
    }

    // LỌC DANH SÁCH XÃ VIÊN
    function getFilteredDirectoryMembers() {
      return farmersDirectory50Data.filter(m => {
        // Village filter
        if (currentDirVillage !== 'all' && m.village !== currentDirVillage) return false;
        // Status filter
        if (currentDirStatus !== 'all' && m.status !== currentDirStatus) return false;
        // Standard filter
        if (currentDirStandard !== 'all' && !m.standard.includes(currentDirStandard)) return false;
        // Search query
        if (currentDirSearchQuery) {
          const q = currentDirSearchQuery.toLowerCase();
          const matchName = m.name.toLowerCase().includes(q);
          const matchPhone = m.phone.toLowerCase().includes(q);
          const matchCode = m.code.toLowerCase().includes(q);
          const matchCrop = m.crop.toLowerCase().includes(q);
          const matchVillage = m.village.toLowerCase().includes(q);
          if (!matchName && !matchPhone && !matchCode && !matchCrop && !matchVillage) return false;
        }
        return true;
      });
    }

    // RENDER BẢNG 50 XÃ VIÊN KÈM PHÂN TRANG (10 HỘ / TRANG)
    function renderDirectoryTable() {
      const filtered = getFilteredDirectoryMembers();
      const totalItems = filtered.length;
      const totalPages = Math.ceil(totalItems / dirPageSize) || 1;

      if (currentDirPage > totalPages) currentDirPage = totalPages;
      if (currentDirPage < 1) currentDirPage = 1;

      const startIndex = (currentDirPage - 1) * dirPageSize;
      const endIndex = Math.min(startIndex + dirPageSize, totalItems);
      const pageItems = filtered.slice(startIndex, endIndex);

      // Cập nhật text phân trang
      document.getElementById('dir-page-start').innerText = totalItems === 0 ? '0' : (startIndex + 1);
      document.getElementById('dir-page-end').innerText = endIndex;
      document.getElementById('dir-page-total').innerText = totalItems;
      document.getElementById('dir-current-page').innerText = currentDirPage;
      document.getElementById('dir-total-pages').innerText = totalPages;
      document.getElementById('dir-total-count-badge').innerText = `${totalItems} Hộ Dân`;

      // Cập nhật trạng thái nút Prev/Next
      const btnPrev = document.getElementById('btn-dir-prev');
      const btnNext = document.getElementById('btn-dir-next');
      if (btnPrev) btnPrev.disabled = (currentDirPage <= 1);
      if (btnNext) btnNext.disabled = (currentDirPage >= totalPages);

      // Render số trang
      const pageNumbersContainer = document.getElementById('dir-page-numbers');
      if (pageNumbersContainer) {
        let htmlPages = '';
        for (let i = 1; i <= totalPages; i++) {
          htmlPages += `<button class="btn-page-num ${i === currentDirPage ? 'active' : ''}" onclick="goToDirPage(${i})">${i}</button>`;
        }
        pageNumbersContainer.innerHTML = htmlPages;
      }

      // Render select jump page
      const selectJump = document.getElementById('select-jump-dir-page');
      if (selectJump) {
        let optionsHtml = '';
        for (let i = 1; i <= totalPages; i++) {
          optionsHtml += `<option value="${i}" ${i === currentDirPage ? 'selected' : ''}>Trang ${i} / ${totalPages}</option>`;
        }
        selectJump.innerHTML = optionsHtml;
      }

      // Render nội dung bảng
      const tbody = document.getElementById('directory-members-table-body');
      if (!tbody) return;

      if (pageItems.length === 0) {
        tbody.innerHTML = `<tr><td colspan="10" style="text-align: center; padding: 36px; color: var(--slate-500);">Không tìm thấy xã viên nào phù hợp với điều kiện tìm kiếm.</td></tr>`;
        return;
      }

      tbody.innerHTML = pageItems.map((m, idx) => {
        const stt = startIndex + idx + 1;
        return `
          <tr class="clickable-row" onclick="switchToMemberAdmin('${m.key}')">
            <td style="text-align: center;"><strong style="color: var(--slate-500); font-size: 13.5px;">#${stt}</strong></td>
            <td>
              <div style="display: flex; align-items: center; gap: 10px;">
                <img src="${m.avatar}" alt="${m.name}" style="width: 42px; height: 42px; border-radius: 50%; object-fit: cover; border: 2px solid #059669; flex-shrink: 0;">
                <div>
                  <div style="font-weight: 800; color: var(--slate-900); font-size: 14.5px;">${m.name}</div>
                  <div style="font-size: 12px; color: var(--slate-500);">Mã: <strong>${m.code}</strong> · ${m.age} tuổi · 📞 ${m.phone}</div>
                </div>
              </div>
            </td>
            <td><span style="font-weight: 600; color: var(--slate-700);">${m.village}</span></td>
            <td><span class="table-tag-dept ${m.cropClass || ''}">${m.crop}</span></td>
            <td style="font-weight: 700; color: var(--slate-800);">${m.area}</td>
            <td><span class="status-badge-clean ${m.stdClass}">${m.standard}</span></td>
            <td>
              <div style="font-weight: 700; color: var(--slate-900);">${m.yield}</div>
              <div style="font-size: 12px; color: var(--brand-700); font-weight: 700;">${m.revenue}</div>
            </td>
            <td style="min-width: 140px;">
              <div style="display: flex; justify-content: space-between; font-size: 12px; font-weight: 700; margin-bottom: 4px;">
                <span style="color: var(--brand-700);">${m.progress}%</span>
                <span style="color: var(--slate-500); font-weight: 500;">Chỉ tiêu</span>
              </div>
              <div style="width: 100%; height: 6px; background: var(--slate-200); border-radius: 4px; overflow: hidden;">
                <div style="width: ${m.progress}%; height: 100%; background: #059669; border-radius: 4px;"></div>
              </div>
            </td>
            <td>
              <span class="status-badge-clean ${m.statusClass}">${m.statusLabel}</span>
            </td>
            <td style="text-align: right;">
              <div style="display: flex; justify-content: flex-end; gap: 6px;" onclick="event.stopPropagation();">
                <button class="hero-pill-btn-green" style="font-size: 12px; padding: 5px 12px;" onclick="switchToMemberAdmin('${m.key}')" title="Xem hồ sơ & bảng sản phẩm">
                  Xem Hồ Sơ
                </button>
                <button class="hero-pill-btn-white" style="font-size: 12px; padding: 5px 9px;" onclick="openZaloCallModal('${m.name} - ${m.phone}')" title="Gọi Zalo trao đổi nông vụ">
                  <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }

    // CHUYỂN TRANG DIRECTORY
    function goToDirPage(page) {
      currentDirPage = page;
      renderDirectoryTable();
    }

    // LỌC THEO TỪ KHÓA & TRẠNG THÁI & TIÊU CHUẨN
    function filterDirectoryMembers() {
      const searchInput = document.getElementById('dir-search-input');
      const statusSelect = document.getElementById('dir-status-filter');
      const stdSelect = document.getElementById('dir-standard-filter');

      currentDirSearchQuery = searchInput ? searchInput.value.trim() : '';
      currentDirStatus = statusSelect ? statusSelect.value : 'all';
      currentDirStandard = stdSelect ? stdSelect.value : 'all';
      currentDirPage = 1;
      renderDirectoryTable();
    }

    // LỌC THEO THÔN / BẢN
    function filterDirectoryByVillage(village) {
      currentDirVillage = village;
      currentDirPage = 1;

      // Cập nhật tab active
      ['all', 'dongcat', 'doimo', 'suoihai', 'baigiua', 'damsen'].forEach(vKey => {
        const tab = document.getElementById('dir-tab-village-' + vKey);
        if (tab) tab.classList.remove('active');
      });

      if (village === 'all') document.getElementById('dir-tab-village-all')?.classList.add('active');
      else if (village.includes('Đồng Cát')) document.getElementById('dir-tab-village-dongcat')?.classList.add('active');
      else if (village.includes('Đồi Mơ')) document.getElementById('dir-tab-village-doimo')?.classList.add('active');
      else if (village.includes('Suối Hai')) document.getElementById('dir-tab-village-suoihai')?.classList.add('active');
      else if (village.includes('Bãi Giữa')) document.getElementById('dir-tab-village-baigiua')?.classList.add('active');
      else if (village.includes('Đầm Sen')) document.getElementById('dir-tab-village-damsen')?.classList.add('active');

      renderDirectoryTable();
    }

    // MỞ MODAL THÊM XÃ VIÊN MỚI
    function openAddMemberModal() {
      openGenericModal('modal-add-farmer-member');
    }

    // LƯU HỒ SƠ XÃ VIÊN MỚI VÀO DANH SÁCH
    function saveNewMember() {
      const name = document.getElementById('new-member-name').value.trim();
      const age = parseInt(document.getElementById('new-member-age').value) || 50;
      const village = document.getElementById('new-member-village').value;
      const phone = document.getElementById('new-member-phone').value.trim();
      const crop = document.getElementById('new-member-crop').value.trim();
      const area = document.getElementById('new-member-area').value.trim() || '1.0 ha';
      const standard = document.getElementById('new-member-standard').value;
      const yld = document.getElementById('new-member-yield').value.trim() || '10 Tấn/năm';
      const bank = document.getElementById('new-member-bank').value.trim() || 'Agribank Yên Bình';

      if (!name || !phone || !crop) {
        showToast('⚠️ Vui lòng nhập đầy đủ Tên, Số điện thoại và Cây trồng!');
        return;
      }

      const newKey = 'farmer_' + Date.now();
      const newCode = 'HTX-YB-' + (farmersDirectory50Data.length + 1).toString().padStart(2, '0');

      const newMemberObj = {
        key: newKey,
        code: newCode,
        name: name,
        age: age,
        phone: phone,
        village: village,
        crop: crop,
        cropClass: 'mint',
        area: area,
        standard: standard,
        stdClass: 'approved',
        yield: yld,
        revenue: '0 đ (Mới)',
        orders: '0 Đơn',
        progress: 0,
        status: 'active',
        statusLabel: 'Đang hoạt động',
        statusClass: 'approved',
        avatar: 'bac_ba_avatar.jpg',
        bank: bank,
        address: `${village}, Xã Yên Bình`,
        badge: standard.toUpperCase(),
        subtext: `Mới kết nạp vào HTX Yên Bình năm 2026!`
      };

      farmersDirectory50Data.unshift(newMemberObj);

      // Thêm vào farmersDatabase
      farmersDatabase[newKey] = {
        name: name,
        meta: `Mã: ${newCode} · ${age} tuổi · ${village}, Xã Yên Bình`,
        badge: standard.toUpperCase(),
        avatar: 'bac_ba_avatar.jpg',
        revenue: '0 đ',
        yield: yld,
        orders: '0 Đơn',
        phone: phone,
        bank: bank,
        address: `${village}, Xã Yên Bình`,
        progress: '0%',
        subtext: `Mới kết nạp vào HTX Yên Bình năm 2026!`,
        products: [
          { id: newKey + '_01', name: crop + ' (Chuẩn Tuyển Chọn)', sku: 'SP-NEW-01', standard: standard, stdClass: 'mint', price: '50.000', stock: '100 đơn vị', status: 'approved', img: 'bac_ba_avatar.jpg', notes: 'Nông sản mới kết nạp HTX.', voiceQuote: crop + ' mùa đầu thu hoạch...', voicePrice: '50.000' }
        ]
      };

      closeGenericModal('modal-add-farmer-member');
      currentDirPage = 1;
      renderDirectoryTable();
      showToast(`✓ Đã thêm thành công xã viên mới: ${name} (${newCode})`);
    }

    // XUẤT FILE EXCEL DANH SÁCH 50 XÃ VIÊN
    function exportMembersListExcel() {
      let csvContent = "STT,Mã Xã Viên,Họ Tên,Tuổi,Số Điện Thoại,Thôn/Bản,Cây Trồng,Diện Tích,Tiêu Chuẩn,Sản Lượng,Doanh Thu,Tiến Độ,Trạng Thái\\n";
      farmersDirectory50Data.forEach((m, idx) => {
        csvContent += `${idx + 1},"${m.code}","${m.name}",${m.age},"${m.phone}","${m.village}","${m.crop}","${m.area}","${m.standard}","${m.yield}","${m.revenue}","${m.progress}%","${m.statusLabel}"\\n`;
      });

      const blob = new Blob(["\\ufeff" + csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Danh_Sach_50_Xa_Vien_HTX_Yen_Binh_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      showToast('📥 Đã xuất file CSV/Excel danh sách 50 hộ xã viên thành công!');
    }
'''

target_db = '    const farmersDatabase = {'
if target_db in html and 'const farmersDirectory50Data' not in html:
    html = html.replace(target_db, js_code_to_insert + target_db, 1)

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(html)

print("Finished inserting 50 members directory and management functions successfully!")
