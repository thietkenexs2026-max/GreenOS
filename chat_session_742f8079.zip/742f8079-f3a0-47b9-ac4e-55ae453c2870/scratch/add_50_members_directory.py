import re
import json

filepath = '/Users/hoangminhduc/Downloads/GreenOS/htx-dashboard.html'
with open(filepath, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update CSS to include #view-members-directory
css_target = '#view-member-admin, #view-b2b-orders, #view-ai-content {'
css_replace = '#view-members-directory, #view-member-admin, #view-b2b-orders, #view-ai-content {'
assert css_target in html, "CSS target not found"
html = html.replace(css_target, css_replace, 1)

# 2. Update Sidebar nav-btn-members to open showMembersDirectoryView()
sidebar_target = '''            <button class="sidebar-menu-btn" id="nav-btn-members" onclick="switchToMemberAdmin('bacba')">
              <svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
              Quản Trị Xã Viên
            </button>'''

sidebar_replace = '''            <button class="sidebar-menu-btn" id="nav-btn-members" onclick="showMembersDirectoryView()">
              <svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
              Quản Trị Xã Viên
            </button>'''
assert sidebar_target in html, "Sidebar target not found"
html = html.replace(sidebar_target, sidebar_replace, 1)

# 3. Update overview "Xem tất cả 142 xã viên" to open showMembersDirectoryView()
overview_target = '''            <button class="btn-see-all-coursue" onclick="openAllMembersDirectoryModal()">
              Xem tất cả 142 xã viên
              <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
            </button>'''

overview_replace = '''            <button class="btn-see-all-coursue" onclick="showMembersDirectoryView()">
              Xem tất cả 142 xã viên
              <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
            </button>'''
assert overview_target in html, "Overview target not found"
html = html.replace(overview_target, overview_replace, 1)

# 4. Update view-member-admin top navigation bar to have button to go back to 50 members directory
admin_nav_target = '''          <div class="member-top-nav-bar">
            <button class="btn-coursue-back" onclick="showOverviewView()">
              <span>←</span> Quay lại Tổng quan HTX
            </button>
            <div class="member-breadcrumb">
              Đang quản trị: <strong id="admin-view-breadcrumb">Bác Ba (Hộ 04)</strong>
            </div>
          </div>'''

admin_nav_replace = '''          <div class="member-top-nav-bar">
            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
              <button class="btn-coursue-back" onclick="showMembersDirectoryView()">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                Quay lại Danh Sách 50 Xã Viên
              </button>
              <button class="btn-coursue-back" onclick="showOverviewView()">
                Dashboard
              </button>
            </div>
            <div class="member-breadcrumb">
              Quản trị xã viên &gt; <strong id="admin-view-breadcrumb">Bác Ba (Hộ 04)</strong>
            </div>
          </div>'''
assert admin_nav_target in html, "Admin nav target not found"
html = html.replace(admin_nav_target, admin_nav_replace, 1)

# 5. Insert VIEW 1.5: TRANG QUẢN TRỊ DANH SÁCH 50 XÃ VIÊN right before VIEW 2
view_directory_html = '''        <!-- -------------------------------------------------------------------
             VIEW 1.5: TRANG QUẢN TRỊ DANH SÁCH 50 XÃ VIÊN HTX YÊN BÌNH
             ------------------------------------------------------------------- -->
        <div id="view-members-directory">
          <!-- Navigation Bar Quay Lại -->
          <div class="member-top-nav-bar">
            <button class="btn-coursue-back" onclick="showOverviewView()">
              <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 4px;"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
              Quay lại Dashboard
            </button>
            <div class="member-breadcrumb">
              Quản trị HTX &gt; <strong>Danh Sách 50 Hộ Xã Viên Nòng Cốt</strong>
            </div>
          </div>

          <!-- Hero Profile Quản Trị Xã Viên -->
          <div class="member-coursue-hero" style="background: linear-gradient(135deg, #064E3B 0%, #065F46 100%); color: white; padding: 26px 30px; border-radius: 20px; margin-bottom: 24px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
              <div>
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                  <span class="hero-mini-pill" style="background: rgba(255,255,255,0.2); color: white; font-weight: 700; border: none;">HỆ THỐNG QUẢN TRỊ NÔNG HỘ</span>
                  <span class="hero-mini-pill" style="background: #10B981; color: white; font-weight: 700; border: none;">142 XÃ VIÊN (DEMO 50 HỘ)</span>
                </div>
                <h2 style="font-size: 24px; font-weight: 800; margin: 0 0 6px 0; color: white;">Danh Sách Quản Trị Xã Viên HTX Nông Nghiệp Yên Bình</h2>
                <p style="margin: 0; font-size: 14px; opacity: 0.9; max-width: 650px;">Theo dõi tiến độ sản xuất, mã vùng trồng PUC, tiêu chuẩn OCOP/VietGAP và lịch giải ngân tiền tươi cho 50 hộ xã viên nòng cốt.</p>
              </div>
              <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <button class="hero-pill-btn-white" onclick="openAddMemberModal()">
                  <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
                  Thêm Xã Viên Mới
                </button>
                <button class="hero-pill-btn-white" onclick="exportMembersListExcel()">
                  <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                  Xuất File Excel
                </button>
                <button class="hero-pill-btn-dark" style="background: rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.25);" onclick="broadcastLogisticsZalo()">
                  <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
                  Nhắn Zalo Toàn Xã
                </button>
              </div>
            </div>
          </div>

          <!-- 4 Thẻ Mini Stat Toàn Xã Viên -->
          <section class="mini-stat-trio" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px;">
            <div class="mini-stat-card">
              <div class="mini-left-content">
                <div class="mini-pastel-icon mint">
                  <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                </div>
                <div>
                  <div class="mini-stat-ratio">TỔNG XÃ VIÊN HTX</div>
                  <div class="mini-stat-title" style="color: var(--brand-700);">142 Hộ (50 Nòng Cốt)</div>
                </div>
              </div>
            </div>

            <div class="mini-stat-card">
              <div class="mini-left-content">
                <div class="mini-pastel-icon amber">
                  <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <div>
                  <div class="mini-stat-ratio">DIỆN TÍCH CANH TÁC</div>
                  <div class="mini-stat-title" style="color: var(--slate-900);">128.5 Hecta</div>
                </div>
              </div>
            </div>

            <div class="mini-stat-card">
              <div class="mini-left-content">
                <div class="mini-pastel-icon blue">
                  <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                </div>
                <div>
                  <div class="mini-stat-ratio">SẢN LƯỢNG GOM 2026</div>
                  <div class="mini-stat-title" style="color: #2563EB;">485 Tấn Nông Sản</div>
                </div>
              </div>
            </div>

            <div class="mini-stat-card">
              <div class="mini-left-content">
                <div class="mini-pastel-icon mint">
                  <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <div>
                  <div class="mini-stat-ratio">ĐÃ CHI TRẢ NÔNG DÂN</div>
                  <div class="mini-stat-title" style="color: var(--brand-700);">3.42 Tỷ Đồng</div>
                </div>
              </div>
            </div>
          </section>

          <!-- BẢNG DANH SÁCH 50 XÃ VIÊN & BỘ LỌC ĐA TẦNG -->
          <div class="member-card-container">
            <div class="table-top-toolbar-header" style="flex-direction: column; align-items: stretch; gap: 14px;">
              <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                <div class="table-title-side">
                  <h3>Danh Sách Xã Viên HTX Yên Bình</h3>
                  <span class="pill-category-badge mint" id="dir-total-count-badge">50 Hộ Dân</span>
                </div>

                <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                  <!-- Ô tìm kiếm realtime -->
                  <div style="position: relative; width: 280px;">
                    <input type="text" id="dir-search-input" class="form-input-stylish" style="padding-left: 36px; padding-top: 8px; padding-bottom: 8px; font-size: 13.5px;" placeholder="Tìm tên, SĐT, mã hộ, cây trồng..." oninput="filterDirectoryMembers()">
                    <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--slate-400);"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                  </div>

                  <!-- Dropdown filter trạng thái -->
                  <select id="dir-status-filter" class="form-input-stylish" style="width: auto; padding-top: 8px; padding-bottom: 8px; font-size: 13.5px;" onchange="filterDirectoryMembers()">
                    <option value="all">Tất cả trạng thái</option>
                    <option value="active">Đang hoạt động (46)</option>
                    <option value="verifying">Chờ nghiệm thu (2)</option>
                    <option value="paused">Tạm nghỉ vụ đông (2)</option>
                  </select>

                  <!-- Dropdown filter tiêu chuẩn -->
                  <select id="dir-standard-filter" class="form-input-stylish" style="width: auto; padding-top: 8px; padding-bottom: 8px; font-size: 13.5px;" onchange="filterDirectoryMembers()">
                    <option value="all">Tất cả tiêu chuẩn</option>
                    <option value="OCOP 4★">OCOP 4 Sao Tỉnh</option>
                    <option value="OCOP 3★">OCOP 3 Sao</option>
                    <option value="VIETGAP">Chuẩn VietGAP</option>
                    <option value="HỮU CƠ">Hữu Cơ PGS</option>
                  </select>
                </div>
              </div>

              <!-- Thanh tab thôn xóm -->
              <div style="display: flex; gap: 8px; flex-wrap: wrap; padding-top: 10px; border-top: 1px solid var(--slate-100);">
                <button class="status-tab-btn active" id="dir-tab-village-all" onclick="filterDirectoryByVillage('all')">Toàn Xã (50)</button>
                <button class="status-tab-btn" id="dir-tab-village-dongcat" onclick="filterDirectoryByVillage('Thôn Đồng Cát')">Thôn Đồng Cát (14)</button>
                <button class="status-tab-btn" id="dir-tab-village-doimo" onclick="filterDirectoryByVillage('Thôn Đồi Mơ')">Thôn Đồi Mơ (10)</button>
                <button class="status-tab-btn" id="dir-tab-village-suoihai" onclick="filterDirectoryByVillage('Thôn Suối Hai')">Thôn Suối Hai (10)</button>
                <button class="status-tab-btn" id="dir-tab-village-baigiua" onclick="filterDirectoryByVillage('Thôn Bãi Giữa')">Thôn Bãi Giữa (8)</button>
                <button class="status-tab-btn" id="dir-tab-village-damsen" onclick="filterDirectoryByVillage('Thôn Đầm Sen')">Thôn Đầm Sen (8)</button>
              </div>
            </div>

            <!-- Bảng hiển thị 10 xã viên / trang -->
            <div style="overflow-x: auto; margin-top: 12px; border: 1px solid var(--slate-200); border-radius: 14px;">
              <table class="member-product-table" style="width: 100%;">
                <thead>
                  <tr>
                    <th style="width: 45px; text-align: center;">#STT</th>
                    <th>HỘ XÃ VIÊN & MÃ SỐ</th>
                    <th>ĐỊA BÀN</th>
                    <th>CÂY TRỒNG CHỦ LỰC</th>
                    <th>QUY MÔ</th>
                    <th>TIÊU CHUẨN</th>
                    <th>SẢN LƯỢNG / DOANH THU</th>
                    <th>TIẾN ĐỘ THU HOẠCH</th>
                    <th>TRẠNG THÁI</th>
                    <th style="text-align: right;">QUẢN TRỊ</th>
                  </tr>
                </thead>
                <tbody id="directory-members-table-body">
                  <!-- Được nạp tự động qua JavaScript -->
                </tbody>
              </table>
            </div>

            <!-- Phân trang 5 trang (10 xã viên / trang) -->
            <div class="table-pagination-footer" style="margin-top: 16px;">
              <div class="pagination-info-text">
                Hiển thị <strong id="dir-page-start">1</strong> - <strong id="dir-page-end">10</strong> trong số <strong id="dir-page-total">50</strong> hộ xã viên (Trang <strong id="dir-current-page">1</strong>/<span id="dir-total-pages">5</span>)
              </div>
              <div class="pagination-controls-wrap">
                <button class="btn-page-nav" id="btn-dir-prev" onclick="goToDirPage(currentDirPage - 1)">
                  <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg> Trước
                </button>
                <div class="page-number-buttons" id="dir-page-numbers"></div>
                <button class="btn-page-nav" id="btn-dir-next" onclick="goToDirPage(currentDirPage + 1)">
                  Sau <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                </button>
                <div class="page-jump-select-wrap">
                  <span>Trang:</span>
                  <select id="select-jump-dir-page" class="select-jump-control" onchange="goToDirPage(parseInt(this.value))">
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>

'''

view_2_marker = '''        <!-- -------------------------------------------------------------------
             VIEW 2: TRANG QUẢN TRỊ XÃ VIÊN & BẢNG SẢN PHẨM CÓ POPUP PHÊ DUYỆT
             ------------------------------------------------------------------- -->'''

assert view_2_marker in html, "View 2 marker not found"
html = html.replace(view_2_marker, view_directory_html + view_2_marker, 1)

# 6. Add Modal "Thêm Xã Viên Mới" (modal-add-farmer-member) before closing body
modal_add_member_html = '''  <!-- Modal: Thêm Xã Viên Mới Vào HTX -->
  <div id="modal-add-farmer-member" class="modal-backdrop-overlay" onclick="closeGenericModalOnBackdrop(event, 'modal-add-farmer-member')">
    <div class="modal-content-container" style="max-width: 600px;" onclick="event.stopPropagation()">
      <div class="modal-header-toolbar">
        <div>
          <h3>Thêm Hộ Xã Viên Mới Vào HTX Yên Bình</h3>
          <p>Đăng ký hộ nông dân vào hệ thống chuỗi giá trị và cấp mã số vùng trồng</p>
        </div>
        <button class="btn-close-modal" onclick="closeGenericModal('modal-add-farmer-member')"><svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>
      </div>

      <div style="display: flex; flex-direction: column; gap: 14px; margin-top: 14px;">
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 14px;">
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Họ Và Tên Chủ Hộ:</label>
            <input type="text" id="new-member-name" class="form-input-stylish" placeholder="Ví dụ: Bác Tám (Đỗ Văn Tám)">
          </div>
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Tuổi:</label>
            <input type="number" id="new-member-age" class="form-input-stylish" placeholder="Ví dụ: 58" value="55">
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Thôn / Xóm Canh Tác:</label>
            <select id="new-member-village" class="form-input-stylish">
              <option value="Thôn Đồng Cát">Thôn Đồng Cát</option>
              <option value="Thôn Đồi Mơ">Thôn Đồi Mơ</option>
              <option value="Thôn Suối Hai">Thôn Suối Hai</option>
              <option value="Thôn Bãi Giữa">Thôn Bãi Giữa</option>
              <option value="Thôn Đầm Sen">Thôn Đầm Sen</option>
            </select>
          </div>
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Số Điện Thoại (Zalo):</label>
            <input type="text" id="new-member-phone" class="form-input-stylish" placeholder="Ví dụ: 0912.888.999">
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 14px;">
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Cây Trồng / Nông Sản Chủ Lực:</label>
            <input type="text" id="new-member-crop" class="form-input-stylish" placeholder="Ví dụ: Chuối Tiêu Hồng / Trà Bát Tiên">
          </div>
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Quy Mô (Diện Tích):</label>
            <input type="text" id="new-member-area" class="form-input-stylish" placeholder="Ví dụ: 1.5 ha" value="1.5 ha">
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Tiêu Chuẩn Đăng Ký:</label>
            <select id="new-member-standard" class="form-input-stylish">
              <option value="OCOP 4★ Tỉnh">OCOP 4 Sao Tỉnh</option>
              <option value="OCOP 3★">OCOP 3 Sao</option>
              <option value="VIETGAP">Chuẩn VietGAP</option>
              <option value="HỮU CƠ">Hữu Cơ PGS</option>
            </select>
          </div>
          <div>
            <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Sản Lượng Dự Kiến / Năm:</label>
            <input type="text" id="new-member-yield" class="form-input-stylish" placeholder="Ví dụ: 12 Tấn/năm" value="12 Tấn/năm">
          </div>
        </div>

        <div>
          <label style="font-weight: 700; font-size: 13.5px; color: var(--slate-800); display: block; margin-bottom: 6px;">Tài Khoản Ngân Hàng Chi Trả Tiền Tươi:</label>
          <input type="text" id="new-member-bank" class="form-input-stylish" placeholder="Ví dụ: Agribank Yên Bình - 8802.205.xxx">
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 14px;">
          <button class="btn-coursue-back" onclick="closeGenericModal('modal-add-farmer-member')">Hủy Bỏ</button>
          <button class="hero-pill-btn-green" onclick="saveNewMember()">
            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
            Lưu Hồ Sơ Xã Viên
          </button>
        </div>
      </div>
    </div>
  </div>

'''

modal_marker = '  <!-- Modal 1: Duyệt Nông Sản Đăng Lên Sàn -->'
assert modal_marker in html, "Modal marker not found"
html = html.replace(modal_marker, modal_add_member_html + modal_marker, 1)

# 7. Update hideAllMainViews() to hide view-members-directory
hide_views_target = '''    function hideAllMainViews() {
      document.getElementById('view-overview').style.display = 'none';'''

hide_views_replace = '''    function hideAllMainViews() {
      if (document.getElementById('view-members-directory')) document.getElementById('view-members-directory').style.display = 'none';
      document.getElementById('view-overview').style.display = 'none';'''

assert hide_views_target in html, "hideAllMainViews target not found"
html = html.replace(hide_views_target, hide_views_replace, 1)

print("Step 1 of replacements finished cleanly.")
with open(filepath, 'w', encoding='utf-8') as f:
    f.write(html)
