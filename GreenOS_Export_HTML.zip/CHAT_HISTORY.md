# Lịch Sử Trao Đổi & Tiến Trình Phát Triển GreenOS

Tài liệu này lưu trữ toàn bộ các yêu cầu, phản hồi và quyết định thiết kế xuyên suốt dự án **GreenVillageOS**.

---

## 📅 Dòng Sự Kiện & Các Yêu Cầu Của Người Dùng

### Giai đoạn 1: Khởi tạo ý tưởng & Thiết lập Design System
- **Yêu cầu 1-6**: Phân tích tài liệu gốc, xác định mô hình nền tảng số hóa nông thôn đa tầng (Hộ nông dân $\rightarrow$ HTX $\rightarrow$ Hub Xã $\rightarrow$ Lãnh đạo Xã). Người dùng nhấn mạnh tệp khách hàng nông dân là những người lớn tuổi, đòi hỏi giao diện rõ ràng, cực kỳ đơn giản và dễ thao tác.
- **Yêu cầu 7-12**: Người dùng chia sẻ hình ảnh tham khảo Scout Voice-First UI (`media_1791194189767.png`), yêu cầu thiết lập bộ Design System bài bản với skill `ui-ux-pro-max` trước khi code.
- **Quyết định**: Xây dựng file `design-system.md` và `tokens.css` chuẩn quy cách Figma tokens, màu xanh nông nghiệp đặc trưng (`#15803D`, `#166534`), tỷ lệ cong lớn (`var(--radius-pill)`), cấu trúc giao diện mobile chuẩn iPhone 16 Pro ($414\text{px} \times 870\text{px}$).

---

### Giai đoạn 2: Hiện thực hóa Persona 1 — Hộ Nông Dân (Bác Ba)
- **Yêu cầu 13-14**: "Giao diện nhìn AI quá, tôi muốn làm hiện đại như mấy mẫu tôi gửi".
  - *Giải pháp*: Tái cấu trúc lại layout theo phong cách Scout, chuyển từ form nhập liệu truyền thống sang Voice-First + Card-based.
- **Yêu cầu 15-18**: Bóc tách trải nghiệm người dùng già:
  - Phải có **Giao diện mở đầu (Trang chủ)** khi người dùng mở ứng dụng trước khi vào đăng bán.
  - Phải chia thành **quy trình theo bước (Wizard 3 bước)** rõ ràng, tuyệt đối không gom chung vào 1 màn hình gây bối rối cho người già.
- **Yêu cầu 19**: Tạo ảnh thực tế cho sản phẩm, phóng to ảnh và mô phỏng việc chia sẻ sang Zalo.
  - *Giải pháp*: Tạo ảnh thực tế túi chuối sấy giòn mặt trước, mặt sau bảng dinh dưỡng; xây dựng màn mô phỏng app Zalo native (Nhật Ký & Nhóm chat).

---

### Giai đoạn 3: Tinh chỉnh điều hướng, Banners & Quản lý đơn hàng
- **Yêu cầu 20-21**: "điều chỉnh lại các nút nhé, với cả không có thanh menu ở cho user dùng à" $\rightarrow$ Bổ sung thanh điều hướng đáy Native 5-tab đối xứng (`Trang chủ`, `Kho hàng`, `Đăng bán ➕`, `Chợ Xã`, `Hỗ trợ Hub`).
- **Yêu cầu 22-24**: 
  - Thêm section banner khuyến mại kích cầu nông sản trên cùng với hiệu ứng trượt tự động.
  - Giảm chiều cao banner xuống $112\text{px}$ để đảm bảo vừa vặn màn hình.
  - Tạo lại banner panorama không bị crop chữ (Hội Chợ Tết & Hội Chợ OCOP).
- **Yêu cầu 25-26**:
  - Hỗ trợ đăng nhiều ảnh trong 1 sản phẩm: Thêm ảnh chụp đĩa chuối sấy thật giòn rụm (`banana_plate.jpg`), bộ gallery thumbnail chuyển ảnh nhanh và lưới 3 ảnh chuẩn Zalo.
  - Thu gọn thẻ Trợ lý bán hàng.
  - Bổ sung section 2 thẻ thống kê: **Đơn hàng đã bán (18 đơn)** và **Doanh thu tháng (3.850.000 đ)**, bấm vào chuyển sang màn hình con chi tiết. Toàn bộ nội dung trang chủ phải **Fit Screen (không cuộn)**.
- **Yêu cầu 27-28**:
  - Thẻ CTA đăng bán sản phẩm mới chuyển sang nền xanh lá đồng bộ thương hiệu Green Village.
  - Tạo avatar chân thực cho Bác Ba (`bac_ba_avatar.jpg`), loại bỏ nhãn "Thí điểm 90 ngày".
- **Yêu cầu 29**: Bỏ biểu tượng icon (📦 và 💰) ở 2 thẻ doanh thu và đơn hàng để giao diện thoáng, tinh tế theo phong cách typographic.

---

### Giai đoạn 4: Trợ năng & Typography cho Người Lớn Tuổi
- **Yêu cầu 30**: "dùng tất cả font inter đi"
  - *Giải pháp*: Nhúng Google Font `Inter` đầy đủ trọng số (400, 500, 600, 700, 800, 900), cấu hình biến toàn cục `--font-sans` và ép kế thừa toàn bộ các thẻ nhập liệu, nút bấm.
- **Yêu cầu 31**: "căn chỉnh lại text nhé đang sát nhau, với cả tăng kích thước chữ lên cho người dùng cao tuổi mà"
  - *Giải pháp*:
    - Tăng `line-height` toàn diện lên $1.5 - 1.65$.
    - Mở rộng đệm và khoảng cách giữa các nhãn, số liệu, dòng mô tả.
    - Nâng cấp toàn bộ thang kích thước chữ: loại bỏ chữ nhỏ dưới $12\text{px}$, chữ thân đạt $15\text{px} - 16\text{px}$, tiêu đề $18.5\text{px} - 22.5\text{px}$, số liệu thống kê $20\text{px} - 32\text{px}$.
- **Yêu cầu 32-33**: Đẩy toàn bộ code và lịch sử trao đổi lên GitHub repository GreenOS.

---

### Giai đoạn 5: Hiện thực hóa Persona 2 — Quản Lý Hợp Tác Xã (HTX Đồng Cát) trên Web PC
- **Yêu cầu 34**: "giờ triển khai làm dashboard cho hợp tác xã nhé, build trên web pc"
  - *Giải pháp*:
    - Xây dựng file `htx-dashboard.html` chuẩn Desktop SaaS Web (1440px+ responsive).
    - **Header & Chỉ số đồng bộ**: Kết nối trực tiếp Shopee Mall, TikTok Shop, Zalo OA Nông Sản Xã, Cổng điều hành Xã Yên Bình.
    - **Hệ thống 6 Tab điều hành**:
      1. *Tổng quan chỉ số*: 4 KPI Card (Doanh thu đa kênh 148tr, Sản lượng 12.4 tấn, Hồ sơ chờ duyệt, 685 đơn xuất kho).
      2. *Duyệt nông sản xã viên (Product Approval)*: Xem ảnh chụp thực tế từ vườn của Bác Ba (`banana_front.jpg`, `banana_plate.jpg`, `banana_back.jpg`), đối chiếu đoạn ghi âm giọng nói giá bán (Voice-First), cấu hình tỷ lệ chiết khấu HTX, phê duyệt 1-chạm đẩy thẳng lên sàn TMĐT.
      3. *Order Hub đa kênh*: Gom đơn sỉ B2B WinMart 1.200 túi + đơn lẻ Shopee/TikTok/Zalo, in phiếu vận đơn kèm mã QR Trace.
      4. *Kho hàng & Bao bì*: Theo dõi tồn kho thực tế, kết nối và đặt in 3.000 túi zipper màng nhôm với xưởng in bao bì Tân Á Hưng Yên.
      5. *AI Content & Livestream Studio*: Trợ lý AI tạo kịch bản Livestream TikTok, caption Zalo OA và mô tả Shopee Mall chuẩn SEO & OCOP.
      6. *Báo cáo BLĐ Xã*: Mẫu báo cáo định kỳ kinh tế số, xuất file Excel và PDF gửi UBND Xã Yên Bình.
    - **Liên kết 2 chiều**: Tích hợp nút chuyển đổi nhanh giữa App Mobile Bác Ba (`index.html`) và Dashboard Quản lý HTX (`htx-dashboard.html`).

---

### Giai đoạn 6: Mở rộng tính năng HTX — 4 Bảng Tổng Hợp Vận Hành & AI Copilot Trợ Lý Quản Trị
- **Yêu cầu 35-37**: "ở phần HTX dashboard thì tư duy với tôi xem cần thêm tính năng gì không nhé", "thêm ý tưởng đi", "có tính năng chat AI để hỗ trợ user không", "thêm tất cả vào nhé, cả bảng tổng hợp và tính năng AI chat hỗ trợ".
  - *Giải pháp*:
    1. **Bảng Quyết toán tiền nông sản cho xã viên (Settlement Table)**: Quản lý số dư, sản lượng cung tiêu, tài khoản ngân hàng, tạo mã VietQR chuyển tiền tự động 1-chạm và in phiếu đối soát tài chính.
    2. **Bảng Điều phối đội xe gom hàng liên thôn (Logistics Fleets)**: Quản lý đội xe tải 1.25T - 2.5T, phân bổ lộ trình gom chuối/chè liên thôn, tải trọng và nút gọi điện Zalo cho tài xế.
    3. **Bảng Mua chung vật tư & Bao bì số lượng lớn (Group Buy)**: Gom đơn mua bao bì màng nhôm, phân bón hữu cơ số lượng lớn, giảm chi phí đầu vào 20-30% cho bà con xã viên.
    4. **Bảng Radar giá nông sản thời gian thực 3 miền**: Đối chiếu giá thu mua tại vườn HTX với chợ đầu mối Long Biên (Hà Nội), Thủ Đức (TP.HCM) và sàn TMĐT, kèm khuyến nghị biên độ giá an toàn.
    5. **AI Copilot Trợ Lý Quản Trị HTX 2 chiều**: Cửa sổ chat AI nổi góc dưới bên phải, phân tích câu hỏi ngữ cảnh tự nhiên (kiểm tra tồn kho, gợi ý giá xuất khẩu, kịch bản đàm phán hợp đồng sỉ B2B) với tốc độ phản hồi tức thì.

---

### Giai đoạn 7: Kích hoạt 100% Tương Tác Tất Cả Nút Bấm & 16 Popup Modals Chức Năng
- **Yêu cầu 38**: "thêm tất cả các màn tương ứng với các nút nhé, để tất cả các nút phải hoạt động".
  - *Giải pháp*:
    - Xây dựng 16 Modal / Popup chuyên sâu: Xem hợp đồng B2B WinMart/Co.opMart, Xuất file Excel thật (tạo file blob định dạng CSV/XLS tải trực tiếp về máy), Gọi điện thoại/Zalo kết nối tức thì, Định vị GPS bản đồ điểm thu gom nông sản thôn, Xem chi tiết hồ sơ nông hộ 142 xã viên, Quét thanh toán VietQR ngân hàng, v.v.
    - Kích hoạt 100% các nút bấm trên toàn bộ giao diện HTX Dashboard, gắn cờ xử lý sự kiện đầy đủ, loại bỏ hoàn toàn các nút chết không phản hồi.

---

### Giai đoạn 8: Chuẩn hóa Vector SVG & Sửa Lỗi Bảng Đơn Buôn B2B
- **Yêu cầu 39**: "loại bỏ các icon trong nút, thay vào đó là các icon SVG tương ứng, với cả bảng ở đơn buôn B2B đang bị lỗi, kiểm tra lại".
  - *Giải pháp*:
    - Thay thế toàn bộ biểu tượng thô (emoji) trong tất cả các thẻ `<button>` bằng bộ **Vector SVG thuần túy** chuẩn UI/UX Pro Max (`stroke-width: 2px`, `viewBox="0 0 24 24"`, kích thước 16x16px hoặc 18x18px cân đối).
    - Tái cấu trúc và sửa triệt để bảng Đơn buôn B2B: Bổ sung đủ 4 hợp đồng sỉ lớn (WinMart 1.200 túi, Co.opMart 800 túi, Bách Hóa Xanh 1.500 túi, Chuỗi Trái Cây Sạch LuLu 500 túi), sửa lỗi vỡ khung, khắc phục các thẻ HTML lồng nhau không đóng.

---

### Giai đoạn 9: Trang Quản Trị 50 Xã Viên, Bộ Lọc Đa Tầng & Phân Trang Động
- **Yêu cầu 40**: "sao trong danh sách quản trị xã viên lại không có list xã viên, demo list 50 xã viên đi".
  - *Giải pháp*:
    - Xây dựng phân hệ Quản lý xã viên độc lập (`view-members-directory`) tích hợp cơ sở dữ liệu **50 hồ sơ xã viên thực tế** phủ khắp 4 thôn (Thôn Đồng Cát, Thôn Yên Lạc, Thôn Đồi Chè, Thôn Bãi Soi).
    - **Bộ lọc 4 tiêu chí kết hợp**: Lọc theo Thôn (4 thôn), Lọc theo Tiêu chuẩn canh tác (VietGAP, OCOP 4 sao, Hữu cơ Organic, GlobalGAP), Lọc theo Cây trồng chủ lực (Chuối sấy, Trà cổ thụ, Mật ong rừng, Gạo sén cù), và Ô tìm kiếm theo tên/SĐT phản hồi thời gian thực.
    - **Phân trang động chuẩn Desktop**: Hiển thị 10 xã viên/trang, bộ nút chuyển trang thông minh kèm thông số đếm xã viên realtime.
    - **Modal Thêm Mới Xã Viên**: Tích hợp form modal 9 trường thông tin hoàn chỉnh (`modal-add-farmer-member`) cho phép ban quản trị thêm xã viên mới trực tiếp vào danh sách.

---

### Giai đoạn 10: Tối Ưu Độ Giãn Cách Bảng (Anti-Cramping) & Đồng Bộ Hoàn Hảo Toàn Bộ Nút Bấm
- **Yêu cầu 41**: "điều chỉnh lại bảng quản trị đi, thông tin díu quá, với cả đồng bộ lại tất cả các button nhé, có những button đang lỗi".
  - *Giải pháp*:
    - **Khắc phục tình trạng bảng bị díu thông tin**: Bọc toàn bộ bảng quản trị trong khung cuộn ngang chuyên nghiệp `.table-responsive-box`, cố định chiều rộng tối thiểu `min-width: 1420px`.
    - **Mở rộng đệm ô và tăng tính dễ đọc**: Đệm `th` mở rộng thành `16px 20px`, đệm `td` đạt `18px 20px`, chiều cao dòng thoáng đãng, nâng kích thước chữ tên xã viên lên `15px` kèm màu tương phản cao, badge trạng thái bo tròn dạng pill có đệm rộng.
    - **Đồng bộ toàn bộ 181 nút bấm**:
      - Sửa lỗi nút Audio Simulation Player và icon Loa trong modal nghe duyệt sản phẩm thành Vector SVG mượt mà.
      - Thêm class `.btn-close-modal` và hành vi đóng cho các modal VietQR và AI Copilot.
      - Liên kết đầy đủ 9 trường ID trong modal thêm xã viên, kiểm tra xác thực dữ liệu và tự động reload bảng dữ liệu.
      - Kiểm thử toàn diện: 181 nút bấm hoạt động 100%, 0 nút lỗi, 0 icon emoji thô trong nút.

---

### Giai đoạn 11: Đóng Gói Lịch Sử Trao Đổi, Sao Lưu Session & Đồng Bộ GitHub Toàn Diện
- **Yêu cầu 42**: "push hết thông tin chat và code lên git nhé".
  - *Giải pháp*:
    - Trích xuất toàn bộ 82 tin nhắn trao đổi xuyên suốt dự án từ `transcript_full.jsonl` vào file [chat_history_742f8079.html](chat_history_742f8079.html).
    - Cập nhật đầy đủ tài liệu tiến trình [CHAT_HISTORY.md](CHAT_HISTORY.md).
    - Tạo gói nén sao lưu phiên làm việc hoàn chỉnh `chat_session_742f8079.zip`.
    - Đẩy toàn bộ mã nguồn, tài liệu và lịch sử lên GitHub repository `git@github.com:thietkenexs2026-max/GreenOS.git` (nhánh `main`).

---

### Giai đoạn 12: Bảng Sản Phẩm 1 Dòng (Nowrap), Bộ Lọc Trạng Thái Header, Demo 50 Nông Sản & Phân Trang Động
- **Yêu cầu 43**: "trong bảng dasboard của user thì có bảng liệt kê các sản phẩm sau đó sẽ có thanh menu select các trạng thái, đang chờ duyệt, đã duyệt, đã xóa, không được duyệt", "cái bảng là menu là filter ở trên cùng bảng thôi ai lại để như kia, mà chỉnh hết chữ về font inter đi, ngoài ra căn chỉnh lại bảng mỗi 1 sản phẩm để 1 dòng thôi không xuống dòng, bảng có thể thiển thị được 10 sản phẩm và select trang kế, demo 50 sản phẩm đi".
  - *Giải pháp*:
    - **Tích hợp thanh lọc trạng thái (Filter Toolbar) ngay trên Header bảng**: Loại bỏ khối lọc rời, đặt gọn gàng cạnh tiêu đề: Tất cả (50), Đang chờ duyệt (12), Đã duyệt (24), Không được duyệt (8), Đã xóa (6) kèm dropdown select nhanh trạng thái.
    - **Căn chỉnh bảng chuẩn 1 dòng tuyệt đối (White-space: nowrap)**: Áp dụng `nowrap` cho toàn bộ các ô trong bảng, đảm bảo mỗi sản phẩm nằm trọn vẹn trên đúng 1 dòng duy nhất, không rớt dòng.
    - **Cơ sở dữ liệu 50 sản phẩm nông sản thực tế**: Nạp đầy đủ 50 sản phẩm nông sản chế biến OCOP/VietGAP phong phú của Bác Ba (chuối sấy giòn, chuối dẻo, kẹo chuối gừng, rượu chuối hột, bột chuối xanh, chuối sấy thăng hoa...).
    - **Phân trang động chuyên nghiệp (Dynamic Pagination)**: Hiển thị 10 sản phẩm/trang, bộ nút chuyển trang ‹ Trước, 1..5, Sau › kèm menu dropdown [Trang 1 ▼] chuyển trang tức thì. Tự động chia lại trang khi áp dụng bộ lọc trạng thái.

---

### Giai đoạn 13: Bỏ Icon Trong Trạng Thái, Modal Popup Duyệt/Kiểm Định & Tư Duy Đồng Bộ Các Màn
- **Yêu cầu 44**: "bỏ icon trong các trạng thái đi, với cả sửa duyệt thì làm gì, Phần trong ảnh thì khi click vào sản phẩm trong bảng sẽ hiện lên popup để duyệt hoặc hiển thị các trạng thái đã duyệt hoặc tạm dừng, xóa ... . Tư duy các màn khác nhé".
  - *Giải pháp*:
    - **Loại bỏ toàn bộ emoji icon trong trạng thái**: Các nhãn và tab lọc chỉ dùng chữ thuần khiết, thanh lịch (Tất cả, Đang chờ duyệt, Đã duyệt, Tạm dừng, Không được duyệt, Đã xóa).
    - **Modal Popup Kiểm Định & Phê Duyệt Nông Sản (Chuẩn 100% theo ảnh mẫu `media_1791305122429.png`)**: Bỏ phần sửa inline phía dưới trang, khi click vào bất kỳ dòng sản phẩm nào trong bảng sẽ mở popup:
      - 3 ảnh thực địa sắc nét (Mặt trước bao bì, Mặt sau thành phần & HSD, Tem OCOP/Mã vạch).
      - Trình mô phỏng nghe file ghi âm giọng nói nông dân kèm thanh tiến trình và hiển thị thời lượng (0:18 / 0:42).
      - Các ô nhập liệu có nút [✕] đỏ xóa nhanh toàn bộ nội dung chỉ bằng 1 chạm.
      - 4 nút tác vụ trạng thái: `Xóa Vào Lưu Trữ`, `Tạm Dừng Bán`, `✕ Không Được Duyệt (Trả Về)`, `✓ Phê Duyệt Nông Sản Lên Sàn ➔`.
    - **Tư duy đồng bộ các màn hình trên Sidebar**:
      - 📊 Dashboard Tổng Quan: 3 thẻ KPI nhanh, danh sách nông sản chờ duyệt, bảng đơn hàng mới.
      - 👥 Quản Trị Xã Viên: Hồ sơ chi tiết từng xã viên, biểu đồ 6 tháng, bảng 50 sản phẩm và thiết lập tài khoản.
      - 📦 Đơn Buôn B2B (Order Hub): Quản lý hợp đồng sỉ lớn (WinMart, MM Mega Market, Bách Hóa Xanh), mã vận đơn, phiếu đóng gói QR code.
      - ⚡ Kịch Bản AI (AI Content Studio): Tự động tạo kịch bản Livestream TikTok Shop cho HTX với nút sao chép 1-click.

---

### Giai đoạn 14: Rà Soát Toàn Diện Hệ Thống, Đồng Bộ 100% Font Inter & Chuẩn Hóa Căn Chỉnh 13 Bảng Dữ Liệu
- **Yêu cầu 45**: "kiểm tra rà soát lại toàn bộ, đồng bộ font Inter, kiếm tra tất cả các bảng căn chỉnh lại nội dung".
  - *Giải pháp*:
    - **Đồng bộ hóa 100% Font Inter**: Loại bỏ hoàn toàn các phông chữ khác, áp dụng font Inter đồng nhất trên mọi thẻ HTML, form nhập liệu, tiêu đề, nút bấm, nhãn và bảng số liệu.
    - **Chuẩn hóa toàn bộ 13 bảng dữ liệu trong hệ thống**:
      1. Bảng Nông Sản Chờ Duyệt (Dashboard)
      2. Bảng Đơn Hàng Mới (Dashboard)
      3. Bảng Sản Phẩm Của Xã Viên (Chi tiết xã viên)
      4. Bảng Danh Sách 50 Xã Viên (Thư mục xã viên)
      5. Bảng Hợp Đồng Đơn Buôn B2B (Order Hub)
      6. Bảng Quản Lý Hộ Trồng Chuối (Vùng trồng)
      7. Bảng Lô Đất Canh Tác (Vùng trồng)
      8. Bảng Kế Hoạch Thu Hoạch Dự Kiến (Vùng trồng)
      9. Bảng Radar Giá Thị Trường (Thị trường 3 miền)
      10. Bảng Quản Lý Kho Bao Bì & Vật Tư Mua Chung
      11. Bảng Sổ Cái Ghi Nợ / Khấu Trừ Xã Viên
      12. Bảng Phân Bổ Đơn Xe Gom Hàng Liên Thôn
      13. Bảng Đội Xe & Tài Xế HTX
    - Mỗi bảng đều được bọc trong `.table-responsive-box` với `min-width` tối thiểu từ 900px đến 1420px, đệm ô rộng rãi 14px–18px, căn lề chuẩn mực (Cột text/tên căn trái, Badge/Mã lô/Ngày tháng căn giữa, Giá bán/Số lượng/Doanh thu căn phải).

---

### Giai đoạn 15: Khắc Phục Lỗi Hiển Thị Radar Giá & Kho Bao Bì, Hồ Sơ Hội Viên Động Kèm Số Liệu Riêng Biệt
- **Yêu cầu 46**: "bảng ở rada thị trường không xem được nội dung, bảng ở kho bao bì cũng vậy, bấm xem hồ sơ của hội viên thì ra thông tin của hội viên như doanh thu, đơn hàng, số lượng sản phẩm,...".
  - *Giải pháp*:
    - **Sửa triệt để lỗi không xem được nội dung bảng Radar và Kho bao bì**:
      - Tìm ra nguyên nhân gốc rễ: Lỗi JavaScript TDZ (Temporal Dead Zone - `ReferenceError: Cannot access 'farmersDatabase' before initialization`) do `farmersDirectory50Data.forEach` truy cập `farmersDatabase` trước khi đối tượng này được khai báo ở dòng dưới.
      - Chuyển `farmersDatabase` lên trước dòng duyệt và bọc `min-width: 1100px - 1200px` với thanh cuộn mượt cho cả 2 bảng.
      - Bổ sung 10 dòng dữ liệu thực tế cho bảng Radar giá (so sánh giá sàn vs giá thương lái, biên lợi nhuận +25% đến +38%, khuyến nghị AI) và bảng Kho vật tư bao bì (tồn kho, cảnh báo đặt mua chung, sổ ghi nợ khấu trừ).
    - **Hiện thực hóa Hồ sơ Hội viên Động (Dynamic Member Profile)**:
      - Khi click "Xem hồ sơ" bất kỳ ai trong 50 xã viên ở `view-members-directory`:
        - Tiêu đề & Hero Profile đổi ngay sang tên, ảnh đại diện, số điện thoại, thôn xóm, loại cây trồng của xã viên đó.
        - 4 thẻ KPI thống kê tự động tính toán lại riêng cho xã viên đó: 💰 Doanh thu năm 2026, 📦 Đơn hàng hoàn tất, 🏷️ Tổng số sản phẩm/lô hàng, 🌾 Sản lượng & Tiến độ vụ mùa.
        - Biểu đồ Doanh thu & Sản lượng 6 tháng tự động render tương ứng.
        - Bảng sản phẩm tự động sinh ra danh mục nông sản riêng biệt chuẩn theo cây trồng chủ lực của xã viên đó (ví dụ Bác Ba: các sản phẩm chuối; Bác Sáu: Bưởi da xanh; Chú Năm: Xoài Cát Hòa Lộc; Cô Bảy: Vú sữa Lò Rèn...).
        - Khu vực Thiết lập tài khoản ở cuối trang tự động hiển thị số Zalo, tài khoản ngân hàng và địa chỉ thực địa của đúng xã viên đó.

---

### Giai đoạn 16: Đóng Gói Toàn Bộ Lịch Sử Chat, Đồng Bộ File & Đẩy Lên Git Remote
- **Yêu cầu 47**: "push hết chat với nội dung lên git nhé mai tôi làm tiếp trên công ty".
  - *Giải pháp*:
    - Cập nhật đầy đủ tài liệu tiến trình phát triển dự án [CHAT_HISTORY.md](CHAT_HISTORY.md).
    - Trích xuất toàn bộ 47 tin nhắn thảo luận phiên làm việc mới nhất vào [chat_history.html](chat_history.html) và [chat_history_26eb1c8c.html](chat_history_26eb1c8c.html) với bộ giao diện dark mode hiện đại, typography Inter và thanh chuyển đổi 3 phiên làm việc mượt mà.
    - Đóng gói file nén sao lưu session `chat_session_26eb1c8c.zip`.
    - Đồng bộ hóa toàn bộ mã nguồn và tài liệu giữa 2 thư mục làm việc `c:\Users\pc\Desktop\Chợ xanh` và `C:\Users\pc\Desktop\greenOS`.
    - Commit và `git push origin main` lên GitHub repository `git@github.com:thietkenexs2026-max/GreenOS.git` để người dùng tiếp tục làm việc liền mạch tại văn phòng công ty.

### Giai đoạn 17: Tìm Kiếm Thông Minh, Theo Dõi Tuyến Xe, Xác Nhận Zalo & Rà Soát Chuẩn Hóa UI/UX Pro Max
- **Yêu cầu 48**: Áp dụng kết quả live search tại thanh tìm kiếm toàn cục, bổ sung popup nhập thông tin chuyến xe & bảng theo dõi trạng thái tuyến xe real-time.
- **Yêu cầu 49**: Khi bấm gửi Zalo nhắc bà con, hiển thị modal xác nhận phát sóng với mẫu tin nhắn, tùy chọn nhóm nhận tin và bong bóng mô phỏng Zalo chat trước khi phát lệnh.
- **Yêu cầu 50**: Bổ sung dữ liệu vận hành xã viên chuyên sâu (sổ tín dụng nội bộ & lịch dự báo thu hoạch mùa vụ).
- **Yêu cầu 51**: Rà soát toàn diện UI/UX theo kỹ năng `ui-ux-pro-max`:
  - Chuẩn hóa 100% các nút chức năng trên cả Web HTX và Mobile Bác Ba sang Vector SVG sắc nét, xóa bỏ hoàn toàn ký tự emoji thô sơ trong button.
  - Thiết lập hiệu ứng xúc giác tương tác (`:focus-visible` outline #059669 2.5px và `:active` scale 0.97 với transition 100ms).
  - Tối ưu hóa bảng dữ liệu chống díu chữ (`.table-responsive-box` với `min-width: 950px - 1420px`).
  - Hỗ trợ phím tắt toàn cục `Escape` để đóng modal và đóng dropdown tìm kiếm tức thì.
  - Đảm bảo kiểm tra cú pháp JavaScript đạt chuẩn 100% không còn lỗi ngắt chuỗi hay quote mismatch.

### Giai đoạn 18: Tính Năng Đính Kèm Hình Ảnh Khi Gửi Tin Nhắn Zalo & Xem Trước Bố Cục Ảnh Mô Phỏng
- **Yêu cầu 52**: "gửi tin nhắn zalo có thể thêm ảnh nhé".
  - *Giải pháp*:
    - Bổ sung phân vùng **Đính Kèm Hình Ảnh Nông Sản & Điểm Cân (Tối đa 5 ảnh)** trong modal `#modal-zalo-broadcast-confirm`.
    - Hỗ trợ tải ảnh trực tiếp từ máy tính/điện thoại qua file input và `FileReader` (đọc chuẩn DataURL).
    - Tích hợp thanh công cụ gắn ảnh mẫu nhanh cho nông sản chủ lực (Chuối sấy OCOP, Đĩa chuối kiểm tra, Trà Bát Tiên, Mật ong rừng, Tem truy xuất OCOP).
    - Hiển thị danh sách thumbnail ảnh đã chọn kèm nút xóa nhanh `✕` và bộ đếm số lượng ảnh thời gian thực (`Đã chọn: X / 5 ảnh`).
    - Nâng cấp **Khung Mô Phỏng Bong Bóng Chat Zalo**: Tự động render lưới ảnh thông minh chuẩn giao diện Zalo (`grid-1`, `grid-2`, `grid-3`, `grid-4`, `grid-5`), bo góc mịn, hiển thị ảnh mẫu trước đoạn văn bản và đính kèm nhãn `📷 X ảnh đính kèm chất lượng gốc HD`.
    - Tự động gán bộ ảnh gợi ý phù hợp khi người dùng chuyển đổi giữa 3 mẫu tin nhắn nhanh.
    - Cập nhật thông báo Toast khi phát lệnh gửi thành công: xác nhận số lượng ảnh HD đã gửi kèm qua Zalo OA tới nhóm nhận tin.

---

### Giai đoạn 19: Bổ Sung Trang Dashboard Nông Hộ Cho Mobile App Bác Ba (`index.html`)
- **Yêu cầu 53**: "ở mobile app của bác ba thêm 1 trang dashboard nhé".
  - *Giải pháp*:
    - **Xây dựng phân hệ Dashboard Nông Hộ độc lập (`panel-dashboard`)**: Chuẩn hóa theo Persona 1 cho người lớn tuổi (chữ to, số nét đậm, độ tương phản cao, thao tác 1 chạm, 100% Font Inter).
    - **Lối tắt truy cập nhanh trên Trang chủ (`home-dashboard-banner`)**: Nằm ngay dưới lời chào Bác Ba, hiển thị tổng quan thu nhập 18.45 tr, 42 đơn hàng và nút mở nhanh 1 chạm.
    - **Nâng cấp thanh điều hướng đáy Native 5-Tab (`appBottomNav`)**: Bổ sung tab **Dashboard** (vị trí Tab 2) bên cạnh Trang chủ, Đăng bán (+), Kho hàng và Chợ Xã.
    - **Thẻ Hero Doanh Thu & Dòng Tiền Vụ Tết 2026**: Hiển thị tổng thu nhập **18.450.000 đ** (+15% so với cùng kỳ), phân rã minh bạch giữa tiền đã về tài khoản Agribank (14.600.000 đ) và tiền tạm giữ HTX chờ quyết toán ngày 23 Tết (3.850.000 đ).
    - **Lưới 4 Chỉ Số Vận Hành Nông Vụ Cốt Lõi**:
      - 🌾 **4.2 / 6 Tấn**: Sản lượng chuối Tết (đạt 70% tiến độ vụ mùa).
      - 📦 **42 Đơn Hàng**: 24 đơn sỉ HTX gom cho chuỗi WinMart/Co.op + 18 đơn lẻ Zalo.
      - 🏷️ **7 Mặt Hàng**: Nông sản OCOP 4 sao và chế biến đang lưu hành.
      - 🍌 **88% Loại 1**: Chuẩn buồng loại A trên 1.200 cây chuối đang cho thu hoạch.
    - **Cảnh Báo Lịch Xe Thu Gom Nông Sản HTX (Nóng Hổi Trong Tuần)**: Chuyến xe gom 08:30 sáng Thứ 5 tại Nhà văn hóa Thôn Đồng Cát (Tài xế Chú Hùng - Xe 2.5 tấn) kèm nút bấm 1 chạm gửi tin Zalo xác nhận xuất 500kg hàng.
    - **Tiến Độ Thu Hoạch 2 Khu Vườn Chuối**: Vườn Đồi Đồng Cát (1.2 ha - 2.8 tấn đã cắt đưa vào lò sấy) & Vườn Bãi Bồi Sông (0.8 ha - 1.4 tấn chuối ngự cắt đợt 2 vào 20 tháng Chạp).
    - **Biểu Đồ Doanh Thu 6 Tháng CSS Bars**: Trực quan từ Tháng 8 đến Tháng 1 (Tết) đạt đỉnh kỷ lục, chạm vào từng cột để nghe hoặc xem chi tiết.
    - **Danh Mục 7 Sản Phẩm Nông Sản Đang Bán**: Chuối sấy giòn OCOP, chuối dẻo đóng hộp quà, chuối ngự tươi VietGAP, mật ong rừng, trà Bát Tiên, rượu chuối hột chum sành, bột chuối xanh dinh dưỡng.
    - **Bộ 4 Nút Tác Vụ Nhanh (Big Touch Targets)**: 🎙️ Đăng Bán Mới (Voice-First), 🚚 Báo Xe Cân Chuối, 💳 Mã VietQR Nhận Tiền, 📞 Gọi Cán Bộ Hub.
    - **Trợ Năng Âm Thanh `speakDashboardBrief()`**: Nút loa đọc to tóm tắt số liệu thu nhập và lịch xe gom hàng bằng tiếng Việt cho Bác Ba.
    - **Modal VietQR Ngân Hàng Agribank**: Popup hiện mã QR tài khoản chính chủ của Bác Ba để người mua quét tiền trực tiếp.

---

### Giai đoạn 20: Đóng Gói Toàn Diện Lịch Sử Phiên Chat 5 & Sao Lưu Session Remote
- **Yêu cầu 54**: "đẩy hết lên git nhé để mai tôi làm việc tiếp".
  - *Giải pháp*:
    - Trích xuất toàn bộ 53 tin nhắn trao đổi mới nhất từ `transcript_full.jsonl` vào [chat_history.html](chat_history.html) và [chat_history_phien5.html](chat_history_phien5.html) với bộ giao diện Dark Mode, typography Inter và thanh điều hướng liên kết 5 phiên làm việc xuyên suốt toàn bộ dự án.
    - Cập nhật gói nén sao lưu dữ liệu `chat_session_26eb1c8c.zip`.
    - Đồng bộ hóa 100% dữ liệu sang cả 2 thư mục làm việc cục bộ `c:\Users\pc\Desktop\Chợ xanh` và `C:\Users\pc\Desktop\greenOS`.
    - Commit và `git push origin main` lên GitHub remote repository `git@github.com:thietkenexs2026-max/GreenOS.git` để người dùng tiếp tục làm việc liền mạch vào ngày mai.

### Giai đoạn 21: Tái Cấu Trúc Toàn Diện & Khắc Phục Lỗi Layout Đè Chữ Dashboard Mobile Bác Ba
- **Yêu cầu 55**: "sửa lại trang dashborad mobile của bác ba đang bị lỗi layout, chứ đang đè lên nhau".
  - *Nguyên nhân cốt lõi*:
    1. Cột biểu đồ doanh thu 6 tháng (`chart-bar-pillar`) có chiều cao 100% lồng trực tiếp với số liệu và nhãn khiến nhãn số bị đẩy ngược lên 40px, đè trực tiếp lên tiêu đề section "📈 Doanh thu 6 tháng gần đây".
    2. Thẻ định danh nông hộ (`dash-farmer-badge-card`) gom avatar, tên dài và pill trạng thái trên cùng 1 hàng không có flex-wrap khiến nút trạng thái tràn và đè lên tên xã viên.
    3. Thẻ top bar (`dash-top-bar`) nhồi nhét 3 nút (Back + Badge + Voice) vượt quá 356px chiều rộng container làm vỡ layout.
    4. Thẻ sản phẩm (`dash-product-card`) thiếu `min-width: 0; overflow: hidden;` ở khối trung gian khiến tên sản phẩm dài va chạm với khối giá tiền bên phải.
    5. Các thẻ KPI 4 grid (`dash-kpi-item`) có font số 20px gây tràn dòng trên màn hình hẹp.
  - *Giải pháp triệt để*:
    - **Tái cấu trúc biểu đồ CSS Bars**: Tách riêng khung ray (`chart-bar-track`) cố định 90px có đường trục đáy rõ ràng, giá trị số nằm độc lập bên trên và nhãn tháng nằm bên dưới — loại bỏ 100% hiện tượng số liệu trồi lên đè tiêu đề.
    - **Tách 2 tầng cho thẻ hồ sơ Bác Ba**: Hàng 1 là Avatar to + Tên & Thôn xóm; Hàng 2 là Mã xã viên XV-004 + Pill trạng thái xuất chuối.
    - **Tối ưu Top Bar**: Nút Trang chủ + Badge + Loa nghe đọc co giãn hài hòa, không bao giờ vượt khung 356px.
    - **Chống tràn chữ thẻ sản phẩm**: Bổ sung `dpc-info` với `min-width: 0; flex: 1; text-overflow: ellipsis;` đảm bảo tên dài tự cắt `...` trước khối giá.
    - **Chuẩn hóa Vector SVG**: Thay thế toàn bộ emoji thô (`🌾`, `📦`, `🏷️`, `🍌`, `🎙️`, `🚚`, `💳`, `📞`) trong các thẻ KPI và 4 nút tác vụ nhanh sang 100% Vector SVG sắc nét, đồng bộ chuẩn `ui-ux-pro-max`.

### Giai đoạn 22: Việt Hóa Thuần Việt — Đổi Tên Trang Thành "Thống Kê"
- **Yêu cầu 56**: "đổi tên trang đó là thống kê nhé".
  - *Giải pháp*:
    - **Thanh menu đáy Native Tab 2**: Chuyển nhãn từ `Dashboard` sang `Thống kê`, đồng thời nâng cấp icon sang biểu đồ cột trực quan (`bar-chart-2` Lucide SVG).
    - **Header Top Bar**: Chuyển badge chỉ mục từ `DASHBOARD NÔNG HỘ` sang `THỐNG KÊ NÔNG HỘ`.
    - **Lối tắt nhanh Trang chủ (`home-dashboard-banner`)**: Đổi tiêu đề thành `Thống Kê Nông Hộ`, nút mở `Mở Thống Kê` và icon biểu đồ cột đồng bộ.
    - Giúp người nông dân cao tuổi như Bác Ba tiếp cận dễ hiểu, thuần Việt, không còn từ mượn tiếng Anh mang tính kỹ thuật.

### Giai đoạn 23: Xuất Trọn Bộ HTML Package & Cổng Điều Phối Trình Diễn Cho Team
- **Yêu cầu 57**: "export html để tôi gửi cho team nhé".
  - *Giải pháp*:
    - **Xây dựng Cổng Trình Diễn Toàn Diện ([PORTAL.html](PORTAL.html))**: Tích hợp giao diện trình diễn song song cả 2 nền tảng Mobile App và Web PC SaaS trực tiếp trên một màn hình duy nhất, có nút tải file nén ZIP và điều hướng mở full màn hình.
    - **Lịch sử trao đổi Phiên 6 ([chat_history_phien6.html](chat_history_phien6.html))**: Ghi chép chi tiết toàn bộ các bước khắc phục lỗi layout đè chữ, chuyển đổi tên trang thành "Thống kê", chuẩn hóa SVG và các test kiểm thử.
    - **Hướng dẫn thành viên Team ([HUONG_DAN_CHO_TEAM.txt](HUONG_DAN_CHO_TEAM.txt))**: Hướng dẫn mở trực tiếp bằng bất kỳ trình duyệt nào mà không cần cài đặt môi trường.
    - **Đóng gói file nén `GreenOS_Export_HTML.zip`**: Nén toàn bộ 22 file HTML, CSS, Markdown và ảnh sản phẩm gốc (~5.7 MB) sẵn sàng gửi qua Zalo/Email cho đối tác và thành viên trong nhóm.

---

### Giai đoạn 24: Xuất Bản Độc Lập File Portal Trình Diễn Ra Desktop & Downloads
- **Yêu cầu 58**: "export riêng cái file portal ra đây đi".
  - *Giải pháp*:
    - Sao chép và xuất trực tiếp file `PORTAL_GREENOS.html` ra cả 2 thư mục dễ truy cập nhất của người dùng: `/Users/hoangminhduc/Desktop/PORTAL_GREENOS.html` và `/Users/hoangminhduc/Downloads/PORTAL_GREENOS.html`.
    - Tạo sự thuận tiện tối đa khi chỉ cần click đúp từ Desktop là có thể trải nghiệm ngay lập tức toàn bộ hệ thống GreenOS mà không cần tìm kiếm trong thư mục dự án.

### Giai đoạn 25: Nhúng Base64 100% Toàn Bộ Hình Ảnh — Khắc Phục Lỗi Hiển Thị Ảnh Khi Mở Độc Lập
- **Yêu cầu 59**: "đang lỗi ảnh ở trong file html đó, chỉnh đi".
  - *Nguyên nhân*: Khi gửi file `PORTAL.html` hoặc `PORTAL_GREENOS.html` đi nơi khác hoặc mở độc lập ngoài thư mục dự án, các đường dẫn ảnh cục bộ (`assets/...`) không tìm thấy khiến giao diện bị vỡ ảnh.
  - *Giải pháp*:
    - Chuyển đổi toàn bộ 8 file ảnh thực tế của Bác Ba và Hợp tác xã sang định dạng chuỗi dữ liệu Base64 Data URI:
      - `bac_ba_avatar.jpg` (Chân dung Bác Ba nông dân OCOP)
      - `banana_front.jpg` (Túi chuối sấy dẻo mặt trước)
      - `banana_plate.jpg` (Đĩa chuối sấy dẻo bày mẫu)
      - `banana_back.jpg` (Mặt sau bao bì dinh dưỡng OCOP)
      - `honey_front.jpg` (Mật ong hoa rừng nguyên chất)
      - `tea_front.jpg` (Chè Bát Tiên OCOP đặc sản)
      - `tet_banner.jpg` (Banner Tết cổ truyền rực rỡ)
      - `ocop_banner.jpg` (Banner chứng nhận OCOP 4 sao)
      - `vietqr.png` (Mã thanh toán VietQR Agribank)
    - Nhúng trực tiếp cơ chế nạp Base64 vào bộ nhớ iframe của `PORTAL.html`. Dù file HTML được lưu ở bất kỳ thư mục nào trên máy tính hay điện thoại, 100% hình ảnh luôn hiển thị sắc nét tức thì không cần kết nối mạng.

### Giai đoạn 26: Bổ Sung Toàn Bộ Tính Năng Xem Full Screen & Mở Tab Độc Lập Cho Cả 2 Bản Demo
- **Yêu cầu 60**: "đang chưa có chỗ xem full screen của 2 bản demo à".
  - *Giải pháp*:
    - **Nút Toàn màn hình trung tâm**: Bổ sung nút `⛶ Toàn Màn Hình` tại thanh điều khiển trung tâm và từng thẻ giới thiệu nhanh.
    - **Thanh công cụ lơ lửng Glassmorphism trong chế độ Fullscreen**: Cho phép người dùng chuyển đổi nhanh giữa `📱 Mobile Bác Ba` và `🖥️ Web HTX PC` bằng 1 click.
    - **Phím tắt chuyên nghiệp**: Hỗ trợ phím `F` (bật/tắt Fullscreen), `Esc` (thu nhỏ), `1` (chuyển xem Mobile), `2` (chuyển xem Desktop PC).
    - **Tính năng Mở Tab Độc Lập (`↗ Mở Tab Mới`)**: Tạo Blob URL động để mở riêng biệt từng ứng dụng sang tab trình duyệt mới toanh, xem trực tiếp toàn màn hình native không bị viền portal bao quanh.

### Giai đoạn 27: Nâng Cấp Quản Lý Đơn Hàng Bác Ba Chuẩn Shopee Partner — Bộ Lọc Ngày & STT Nổi Bật
- **Yêu cầu 61**: "chỉnh sửa phần thông tin đơn hàng của bác ba nhé, ở trong đó khi bấm vào màn sẽ là thông tin cơ bản của từng đơn hàng list theo từng ngày có số tứ tự đơn hàng nhé, xong sẽ có filte. Như màn thông tin của shopee này, filter sẽ cho chọn hôm nay, hôm qua, 3 ngày trước, và khoảng thời gian tuỳ chọn".
  - *Giải pháp*:
    - **Thẻ đơn hàng chuẩn Shopee Partner**: Bố cục STT đơn hàng to đậm màu cam (`#FF6B00`), mã đơn `[#GOS-...]`, nhãn trạng thái giao nhận và tài xế nhận đơn.
    - **Hệ thống Tab trạng thái vuốt ngang**: `Tất cả`, `Mới (3)`, `Đang làm (2)`, `Làm xong (1)`, `Đang giao (2)`, `Lịch sử (2)`.
    - **Bộ lọc ngày dạng Bottom Sheet Modal**: Hỗ trợ chọn nhanh: *Hôm nay*, *Hôm qua*, *3 ngày trước*, *7 ngày qua*, *Tháng này*, và *Khoảng thời gian tuỳ chọn* (với 2 ô chọn ngày bắt đầu & kết thúc).
    - **Màn hình Chi tiết đơn hàng chuyên sâu**: Hiển thị thông tin tài xế, gọi điện thoại nhanh, ghi chú đơn hàng đóng khung vàng nổi bật, bảng kê chi tiết từng sản phẩm và dòng tiền nhận thực tế.

### Giai đoạn 28: Tinh Chỉnh Layout Pixel-Perfect (356px) Chống Tràn Text & Đồng Bộ 100% Nông Sản Bác Ba
- **Yêu cầu 62 & 63**: "căn chỉnh lại text cho hợp layout, với cả hiện thị nội dung sao cho hợp với sản phẩm mà bác ba bán nhé", "chỉnh sửa lại text vẫn vỡ layout".
  - *Giải pháp*:
    - **Đồng bộ 100% Nông sản OCOP thực tế của Bác Ba**: Thay thế triệt để các món ăn vặt mẫu sang toàn bộ nông sản Bác Ba sản xuất: Chuối sấy dẻo OCOP, Rượu chuối hột rừng men lá, Chuối sấy giòn hút chân không, Buồng chuối ngự tiến vua, Mật ong hoa rừng Ba Bể, Chè Shan Tuyết Bát Tiên cổ thụ, Bột chuối xanh nguyên chất.
    - **Khắc phục triệt để vỡ layout trên khung màn 356px**:
      - Thu gọn nút quay lại tiêu đề thành nút tròn nhỏ gọn `←` (32px), tạo không gian thoải mái cho tiêu đề "Đơn hàng".
      - Bổ sung `min-width: 0`, `flex-shrink: 1`, `text-overflow: ellipsis` cho nút chọn ngày, đảm bảo chuỗi ngày tháng dài tự động co gọn thanh lịch kèm mũi tên `▼`.
      - Tối ưu bảng thanh toán tài chính theo chuẩn ảnh Shopee thực tế: bên phải chỉ để nút điều hướng `Chi tiết ›`, đưa toàn bộ tên phương thức sang dòng phụ dưới, dẹp bỏ 100% hiện tượng rớt dòng hay tràn màn hình.

### Giai đoạn 29: Đồng Bộ Mã Nguồn Lên GitHub Remote
- **Yêu cầu 64**: "push hết lên git nhé".
  - *Giải pháp*:
    - Kiểm tra và cam kết toàn bộ các tệp tin mã nguồn, tệp tin xuất độc lập và cập nhật tài liệu lịch sử trao đổi.
    - Đẩy toàn bộ các commit (`1b00a2e`, `bda818a`, `945e4b8`, `d3bed9a`, `5263024`) lên nhánh `main` của kho lưu trữ GitHub (`git@github.com:thietkenexs2026-max/GreenOS.git`).

---

### Giai đoạn 30: Nâng Cấp Quy Trình Đăng Bán Step-by-Step & Cho Phép Chỉnh Sửa Trực Tiếp Nội Dung Text
- **Yêu cầu 65**: "trong quá trình đăng tải sản phẩm của bác ba có thể chỉnh sửa được nội dung text chứ, với cả giờ làm các step là các thanh điểm ở trên cùng nhé, kiểu step by step".
  - *Giải pháp*:
    - **1. Thanh điểm tiến trình Step-by-Step ở đầu trang (Wizard Stepper)**:
      - Thiết kế thanh tiến trình 3 điểm nối chuẩn mực cho người lớn tuổi:
        - `Điểm 1 (Chụp ảnh)`: Vòng tròn số 1 hiển thị trạng thái đang thực hiện (xanh đậm, viền nổi) và tự động chuyển sang tích xanh (`✓`) khi hoàn thành.
        - `Thanh nối 1-2`: Tự động lấp đầy dải xanh khi hoàn tất bước 1.
        - `Điểm 2 (Sửa giá & Tin)`: Vòng tròn số 2 kích hoạt khi đến bước thiết lập giá và thông tin.
        - `Thanh nối 2-3`: Kết nối từ bước 2 sang bước 3.
        - `Điểm 3 (Đăng bán)`: Vòng tròn số 3 hoàn tất bài viết và đưa lên Zalo.
      - Hỗ trợ bấm trực tiếp vào từng điểm tròn để quay lại hoặc chuyển bước nhanh chóng (`goToWizardStep(1|2|3)`).
      - Đồng bộ trạng thái tự động qua hàm `updateWizardStepper(stepNum)` trên toàn bộ các bước.
    - **2. Cho phép chỉnh sửa thông tin sản phẩm trực tiếp ở Bước 2**:
      - Thêm thẻ `wizard-edit-card` với các ô nhập liệu trực quan:
        - `Tên sản phẩm nông sản`: Ô nhập gõ chữ hoặc nhận diện tự động từ giọng nói.
        - `Giá bán (VNĐ / gói)`: Ô nhập giá nổi bật kèm hàng nút bấm chọn nhanh trực quan (`45.000đ`, `50.000đ`, `55.000đ`, `60.000đ`, `70.000đ`).
        - `Quy cách đóng gói`: Ô nhập kèm chip chọn nhanh (`250g`, `500g`, `1kg`).
        - `Hạn sử dụng`: Ô nhập kèm chip chọn nhanh (`6 tháng`, `12 tháng`).
        - `Chính sách ưu đãi / Vận chuyển`: Nhập ưu đãi giao hàng tận nhà trong xã.
      - Khi Bác Ba bấm nút thu âm mô phỏng giọng nói (`recordVoiceSimulate()`), hệ thống tự động điền các thông số nhận diện vào các ô nhập liệu và cho phép Bác Ba sửa đổi bất kỳ lúc nào.
    - **3. Khối soạn thảo bài viết trực tiếp ở Bước 3 (Post Text Editor)**:
      - Chuyển đổi khối hiển thị văn bản tĩnh thành ô soạn thảo trực tiếp `post-text-editor` (`textarea`) cỡ chữ 14.5px, giãn dòng thoáng đãng, có viền highlight xanh khi chạm vào.
      - **Bộ 3 mẫu AI gợi ý tức thì (`pec-ai-presets`)**:
        - `🏮 Mẫu Vụ Tết`: Giọng văn ấm áp mừng năm mới, biếu Tết họ hàng.
        - `📦 Mẫu Bán sỉ`: Giọng văn hợp tác xã xuất buôn cho các đại lý, quán ăn, tạp hóa.
        - `🌿 Mẫu Mộc mạc`: Giọng văn chân chất của người nông dân nhà vườn truyền thống.
      - **Nút chèn giọng nói (`dictateIntoPostText`)**: Cho phép Bác Ba đọc thêm một câu cam kết chất lượng vào cuối bài mà không cần bấm phím ảo.
      - **Đọc to bài viết (`listenAudioArticle`)**: Luôn đọc nội dung văn bản mới nhất sau khi bác chỉnh sửa để bác nghe lại bằng tai.
    - **4. Đồng bộ Real-time sang Giao diện Zalo**:
      - Bất kỳ thay đổi nào về tên, giá hoặc nội dung bài viết đều tự động đồng bộ sang Nhật ký Zalo (`#zaloFeedPostContent`) và Tin nhắn nhóm chợ xã (`#zaloChatMessageText`).
      - Bổ sung nút `Quay lại sửa nội dung bài viết` trực tiếp từ màn hình Zalo để bác Ba dễ dàng tinh chỉnh tiếp nếu chưa ưng ý.

---

## 💡 Đúc Kết Thiết Kế Cho Nông Dân & Quản Trị Hợp Tác Xã

1. **Persona 1 — Nông Dân & Người Lớn Tuổi (Mobile App - `index.html`)**:
   - **Voice-First thay thế bàn phím**: Người già tay run, mắt kém, ngại gõ bàn phím ảo. Nút micro to bản kèm trích dẫn văn bản trực quan giúp họ làm chủ ứng dụng ngay lần đầu.
   - **Âm thanh phản hồi (Loa đọc to bài viết)**: Cho phép bà con nghe kiểm chứng nội dung bằng tai trước khi đăng bán.
   - **Thị giác rõ ràng (High Contrast & Large Font)**: Nền sạch, chữ đậm, độ tương phản cao, phông Inter dễ đọc, không dùng icon rườm rà.
   - **Hệ sinh thái Zalo thân thuộc**: Kết nối thẳng với thói quen bán hàng qua Zalo của nông dân Việt Nam.

2. **Persona 2 — Ban Quản Trị Hợp Tác Xã (Web Desktop - `htx-dashboard.html`)**:
   - **Không gian bảng rộng rãi, chuyên nghiệp**: Bảng dữ liệu SaaS cần có `min-width` đủ lớn (1420px+) và padding ô hào phóng (18-20px) để các cột số liệu, thẻ trạng thái và nút tác vụ không bị chen chúc, díu chữ.
   - **Vector SVG chuẩn hóa**: Loại bỏ 100% emoji trong các nút chức năng để đạt đẳng cấp giao diện chuyên nghiệp.
   - **Trợ lý AI Copilot đàm thoại**: Giúp ban quản trị tra cứu nhanh tồn kho, lập kịch bản bán hàng và kiểm tra chính sách OCOP mọi lúc.
   - **Vận hành thực tế khép kín**: Tích hợp thanh toán QR VietQR, quản lý đội xe gom hàng liên thôn, mua chung vật tư và radar giá nông sản 3 miền.
