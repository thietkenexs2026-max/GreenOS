import re

filepath = '/Users/hoangminhduc/Downloads/GreenOS/htx-dashboard.html'
with open(filepath, 'r', encoding='utf-8') as f:
    html = f.read()

replacements = [
    # 1. Member hero actions
    (
        '''            <div class="member-hero-actions">
              <button class="hero-pill-btn-white" onclick="openZaloCallModal('Bác Ba (Hộ 04 - 0912.345.889)')">
                📞 Gọi Zalo
              </button>
              <button class="hero-pill-btn-dark" onclick="saveMemberSettings()">
                💾 Lưu Cài Đặt
              </button>
            </div>''',
        '''            <div class="member-hero-actions">
              <button class="hero-pill-btn-white" onclick="openZaloCallModal('Bác Ba (Hộ 04 - 0912.345.889)')">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>Gọi Zalo
              </button>
              <button class="hero-pill-btn-dark" onclick="saveMemberSettings()">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"/></svg>Lưu Cài Đặt
              </button>
            </div>'''
    ),
    # 2. Member settings save button
    (
        '''            <div style="display: flex; justify-content: flex-end; margin-top: 16px;">
              <button class="hero-pill-btn-dark" onclick="saveMemberSettings()">
                💾 Lưu Thay Đổi Cài Đặt
              </button>
            </div>''',
        '''            <div style="display: flex; justify-content: flex-end; margin-top: 16px;">
              <button class="hero-pill-btn-dark" onclick="saveMemberSettings()">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"/></svg>Lưu Thay Đổi Cài Đặt
              </button>
            </div>'''
    ),
    # 3. Audio voice wave play button
    (
        '''<button class="audio-play-round" onclick="openVoicePreviewModal('Giọng Nói Đối Soát Hộ Dân', document.getElementById('modal-voice-quote').innerText)">▶</button>''',
        '''<button class="audio-play-round" onclick="openVoicePreviewModal('Giọng Nói Đối Soát Hộ Dân', document.getElementById('modal-voice-quote').innerText)" title="Nghe phát lại ghi âm"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" style="margin-left: 2px;"><path d="M8 5v14l11-7z"/></svg></button>'''
    ),
    # 4. Input clear buttons (btn-clear-symbol)
    (
        '''            <input type="text" id="modal-edit-prod-name" class="form-input-stylish" value="Chuối Sấy Giòn Yên Bình (Túi 250g Zip)">
            <button class="btn-clear-symbol" onclick="clearAdminInput('modal-edit-prod-name')" title="Xóa chữ trong ô">✕</button>''',
        '''            <input type="text" id="modal-edit-prod-name" class="form-input-stylish" value="Chuối Sấy Giòn Yên Bình (Túi 250g Zip)">
            <button class="btn-clear-symbol" onclick="clearAdminInput('modal-edit-prod-name')" title="Xóa chữ trong ô"><svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>'''
    ),
    (
        '''              <input type="text" id="modal-edit-prod-price" class="form-input-stylish" value="55.000" style="color: var(--brand-700); font-weight: 800; font-size: 18px;">
              <button class="btn-clear-symbol" onclick="clearAdminInput('modal-edit-prod-price')" title="Xóa giá">✕</button>''',
        '''              <input type="text" id="modal-edit-prod-price" class="form-input-stylish" value="55.000" style="color: var(--brand-700); font-weight: 800; font-size: 18px;">
              <button class="btn-clear-symbol" onclick="clearAdminInput('modal-edit-prod-price')" title="Xóa giá"><svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>'''
    ),
    (
        '''            <input type="text" id="modal-edit-prod-notes" class="form-input-stylish" value="Đạt chuẩn OCOP 4 sao tỉnh theo QĐ 142/QĐ-UBND. Mẫu sấy đạt độ ẩm 4.8%.">
            <button class="btn-clear-symbol" onclick="clearAdminInput('modal-edit-prod-notes')" title="Xóa ghi chú">✕</button>''',
        '''            <input type="text" id="modal-edit-prod-notes" class="form-input-stylish" value="Đạt chuẩn OCOP 4 sao tỉnh theo QĐ 142/QĐ-UBND. Mẫu sấy đạt độ ẩm 4.8%.">
            <button class="btn-clear-symbol" onclick="clearAdminInput('modal-edit-prod-notes')" title="Xóa ghi chú"><svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>'''
    ),
    # 5. Product approval modal action buttons
    (
        '''          <button class="btn-coursue-back" style="color: #DC2626;" onclick="setModalProductStatus('rejected')">
            ✕ Không Được Duyệt (Trả Về)
          </button>
          <button class="banner-cta-button" style="background: var(--brand-600); font-size: 15px;" onclick="setModalProductStatus('approved')">
            <span>✓ Phê Duyệt Nông Sản Lên Sàn</span>
            <div class="banner-cta-arrow"><svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg></div>
          </button>''',
        '''          <button class="btn-coursue-back" style="color: #DC2626;" onclick="setModalProductStatus('rejected')">
            <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>Không Được Duyệt (Trả Về)
          </button>
          <button class="banner-cta-button" style="background: var(--brand-600); font-size: 15px;" onclick="setModalProductStatus('approved')">
            <span style="display: inline-flex; align-items: center; gap: 6px;"><svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>Phê Duyệt Nông Sản Lên Sàn</span>
            <div class="banner-cta-arrow"><svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg></div>
          </button>'''
    ),
    # 6. Copilot Action buttons in responses
    (
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showOverviewView()">📊 Xem Dashboard Tổng</button>
            <button class="copilot-action-btn" onclick="showB2BOrdersView()">📦 Xem Đơn WinMart</button>
          </div>''',
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showOverviewView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>Xem Dashboard Tổng</button>
            <button class="copilot-action-btn" onclick="showB2BOrdersView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>Xem Đơn WinMart</button>
          </div>'''
    ),
    (
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="switchToMemberAdmin('bacba')">👤 Xem Hồ Sơ Bác Ba</button>
            <button class="copilot-action-btn" onclick="openVietQRModal('Bác Ba (Nguyễn Văn Ba)', '5.940.000', 'Agribank - 8802205128899', 'Chuối sấy OCOP')">💳 Mở Mã VietQR</button>
          </div>''',
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="switchToMemberAdmin('bacba')"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>Xem Hồ Sơ Bác Ba</button>
            <button class="copilot-action-btn" onclick="openVietQRModal('Bác Ba (Nguyễn Văn Ba)', '5.940.000', 'Agribank - 8802205128899', 'Chuối sấy OCOP')"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>Mở Mã VietQR</button>
          </div>'''
    ),
    (
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="copyDraftZalo()">📋 Sao Chép Tin Nhắn</button>
            <button class="copilot-action-btn" onclick="broadcastLogisticsZalo()">🚀 Gửi Vào Nhóm Zalo Xã</button>
          </div>''',
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="copyDraftZalo()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/></svg>Sao Chép Tin Nhắn</button>
            <button class="copilot-action-btn" onclick="broadcastLogisticsZalo()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>Gửi Vào Nhóm Zalo Xã</button>
          </div>'''
    ),
    (
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showB2BOrdersView()">📦 Xem Chi Tiết Đơn Buôn</button>
            <button class="copilot-action-btn" onclick="openDispatchSlipModal('WM-8821')">🏷️ In Vận Đơn Kèm QR</button>
          </div>''',
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showB2BOrdersView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>Xem Chi Tiết Đơn Buôn</button>
            <button class="copilot-action-btn" onclick="openDispatchSlipModal('WM-8821')"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>In Vận Đơn Kèm QR</button>
          </div>'''
    ),
    (
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showSuppliesView()">📦 Xem Tồn Kho Bao Bì OCOP</button>
            <button class="copilot-action-btn" onclick="openOcopDossierModal()">📄 Xuất Bộ Hồ Sơ OCOP</button>
          </div>''',
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showSuppliesView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>Xem Tồn Kho Bao Bì OCOP</button>
            <button class="copilot-action-btn" onclick="openOcopDossierModal()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>Xuất Bộ Hồ Sơ OCOP</button>
          </div>'''
    ),
    (
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showSettlementView()">💰 Mở Sổ Quyết Toán Tiền</button>
            <button class="copilot-action-btn" onclick="openVietQRModal('Bác Ba (Nguyễn Văn Ba)', '5.940.000', 'Agribank - 8802205128899', 'Chuối sấy OCOP')">💳 Tạo VietQR Trả Tiền</button>
          </div>''',
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showSettlementView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>Mở Sổ Quyết Toán Tiền</button>
            <button class="copilot-action-btn" onclick="openVietQRModal('Bác Ba (Nguyễn Văn Ba)', '5.940.000', 'Agribank - 8802205128899', 'Chuối sấy OCOP')"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>Tạo VietQR Trả Tiền</button>
          </div>'''
    ),
    (
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showSettlementView()">💰 Sổ Quyết Toán</button>
            <button class="copilot-action-btn" onclick="showLogisticsView()">🚚 Tuyến Xe Thu Gom</button>
            <button class="copilot-action-btn" onclick="showSuppliesView()">📦 Kho Bao Bì & Vật Tư</button>
            <button class="copilot-action-btn" onclick="showRadarView()">📈 Radar Giá Thị Trường</button>
          </div>''',
        '''          <div class="copilot-action-group">
            <button class="copilot-action-btn" onclick="showSettlementView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>Sổ Quyết Toán</button>
            <button class="copilot-action-btn" onclick="showLogisticsView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/></svg>Tuyến Xe Thu Gom</button>
            <button class="copilot-action-btn" onclick="showSuppliesView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>Kho Bao Bì & Vật Tư</button>
            <button class="copilot-action-btn" onclick="showRadarView()"><svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>Radar Giá Thị Trường</button>
          </div>'''
    ),
    # 7. Copilot chip button 4 star text
    (
        '''<button class="copilot-chip-btn" onclick="sendQuickCopilotPrompt('🏷️ Quy trình nâng hạng OCOP 4 sao')"><svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg> Tiêu chuẩn OCOP 4★</button>''',
        '''<button class="copilot-chip-btn" onclick="sendQuickCopilotPrompt('Quy trình nâng hạng OCOP 4 sao')"><svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="vertical-align: -2px; margin-right: 5px;"><path stroke-linecap="round" stroke-linejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg> Tiêu chuẩn OCOP 4 Sao</button>'''
    ),
    # 8. Modal Zalo Call action buttons (Mic, Speaker, Hangup)
    (
        '''      <div style="display: flex; justify-content: center; gap: 16px;">
        <button class="hero-pill-btn-white" style="border-radius: 50%; width: 50px; height: 50px; padding: 0; justify-content: center;" title="Bật/Tắt Mic" onclick="showToast('Đã tắt/bật micro')">🎙️</button>
        <button class="hero-pill-btn-white" style="border-radius: 50%; width: 50px; height: 50px; padding: 0; justify-content: center;" title="Loa ngoài" onclick="showToast('Đã bật loa ngoài âm lượng tối đa')">🔊</button>
        <button style="background: #EF4444; color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; font-size: 20px;" title="Kết thúc cuộc gọi" onclick="closeGenericModal('modal-zalo-call')">📵</button>
      </div>''',
        '''      <div style="display: flex; justify-content: center; gap: 16px;">
        <button class="hero-pill-btn-white" style="border-radius: 50%; width: 50px; height: 50px; padding: 0; justify-content: center;" title="Bật/Tắt Mic" onclick="showToast('Đã tắt/bật micro')"><svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/></svg></button>
        <button class="hero-pill-btn-white" style="border-radius: 50%; width: 50px; height: 50px; padding: 0; justify-content: center;" title="Loa ngoài" onclick="showToast('Đã bật loa ngoài âm lượng tối đa')"><svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"/></svg></button>
        <button style="background: #EF4444; color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; display: flex; align-items: center; justify-content: center;" title="Kết thúc cuộc gọi" onclick="closeGenericModal('modal-zalo-call')"><svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 8l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M5 3a2 2 0 00-2 2v1c0 8.284 6.716 15 15 15h1a2 2 0 002-2v-3.28a1 1 0 00-.684-.948l-4.493-1.498a1 1 0 00-1.21.502l-1.13 2.257a11.042 11.042 0 01-5.516-5.517l2.257-1.128a1 1 0 00.502-1.21L9.928 3.684A1 1 0 008.98 3H5z"/></svg></button>
      </div>'''
    ),
    # 9. Walkie-talkie call driver button
    (
        '''<button class="hero-pill-btn-green" onclick="showToast('Đang kết nối gọi bộ đàm tới tài xế Tuấn...')">📞 Gọi Bộ Đàm Tài Xế</button>''',
        '''<button class="hero-pill-btn-green" onclick="showToast('Đang kết nối gọi bộ đàm tới tài xế Tuấn...')"><svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="margin-right: 6px;"><path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>Gọi Bộ Đàm Tài Xế</button>'''
    )
]

success_count = 0
for target, repl in replacements:
    if target in html:
        html = html.replace(target, repl)
        success_count += 1
    else:
        print(f"Warning: could not find target: {target[:60]}...")

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(html)

print(f"Replaced {success_count}/{len(replacements)} blocks successfully.")
